#pragma once
#include<iostream>
#include<ctime>
#include<vector>
#include<algorithm>
#include<iterator>
#include<string>
#include<regex>
#include<functional>
using namespace std;
class Variants
{
	vector<int>nominals;
	vector<vector<int>>all_variants;
	double sum;
public:Variants();
public:void set_sum();
public:void task_method(vector<int>::iterator );
public:void task_method_helper1(vector<int>&);
public:void realize();
	   vector<int>& helper(vector<int>&,vector<int>::iterator );
	   vector<int>& collect_1_to_2(vector<int>&);
	   vector<int>&collect_1_to_2_helper(vector<int>&, int , int );
	   vector<int>&collect_1_to_5(vector<int>&);
	   vector<int>&collect_1_to_10(vector<int>&);
	   vector<int>&collect_helper(vector<int>&, int );
	   vector<int>&collect_1_to_25(vector<int>&);
	   vector<int>&collect_1_to_50(vector<int>&);
	   vector<int>&collect_5_to_10(vector<int>&);
	   void print();
};