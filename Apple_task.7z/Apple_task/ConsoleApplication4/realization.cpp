#include"header.h"
Variants::Variants()
{
	nominals.push_back(1);
	nominals.push_back(2);
	nominals.push_back(5);
	nominals.push_back(10);
	nominals.push_back(25);
	nominals.push_back(50);
	nominals.push_back(100);
}
void Variants::set_sum()
{
	string Ex = "[0-9]+\.[0-9]{2}";
	regex Ex1(Ex);
	string Ex2 = "";
	while (1)
	{
		getline(cin, Ex2);
		if (regex_match(Ex2, Ex1))
			break;
		else
			cout << "Wrong data, try again.\n";
	}
	char ch = '.';
	string Ex3 = "";
	for (int i = 0; i < Ex2.length(); i++)
	{
		if (Ex2[i] == ch)
			continue;
		Ex3 += Ex2[i];
	}
	int x = stoi(Ex3);
	sum = (double)x / 100;
}
void Variants::task_method(vector<int>::iterator it)
{
	if (it == nominals.end())
		return;
	int per = sum * 100;
	int temp = per / (*it);
	if (temp > 0)
	{
		if ((per % (*it)) == 0)
		{
			vector<int> Exem;
			for (int i = 0; i < temp; i++)
				Exem.push_back(*it);
			task_method_helper1(Exem);
		}
		else
		{
			vector<int>Ex;
			for (int i = 0; i < temp; i++)
				Ex.push_back(*it);
			bool x1 = 0;
			for (int i = 0; i < 6; i++)
				if (per % (*it) == nominals[i])
				{
					x1 = 1;
					break;
				}
			if (x1)
			{
				Ex.push_back(per % (*it));
			}
			else
			{
				int x = per % (*it);
				bool x1 = 1;
				while (x1)
				{
					int a = 0;
					for (int i = 5; i >= 0; i--)
					{
						if (x > nominals[i])
						{
							a = i;
							break;
						}
					}
					int y = x / nominals[a];
					for (int i = 0; i < y; i++)
						Ex.push_back(nominals[a]);
					x = x%nominals[a];
					if (x == 0)
						x1 = 0;
					else
					{
						for (int i = 0; i < 6; i++)
						{
							if (x == nominals[i])
							{
								Ex.push_back(x);
								x1 = 0;
								break;
							}
						}
					}
				}
			}
			task_method_helper1(Ex);
		}
		task_method(it + 1);
	}
	else
		return;
}
void Variants::task_method_helper1(vector<int>&Ex)
{
	all_variants.push_back(Ex);
	vector<int>::iterator it = Ex.end() - 1;
	while (it != Ex.begin())
	{
		if (*it == 1)
		{
			it--;
			continue;
		}
		else if (*it == 2)
			all_variants.push_back(helper(Ex, it));
		else if (*it == 5)
			all_variants.push_back(collect_1_to_2(helper(Ex, it)));
		else if (*it == 10)
			all_variants.push_back(collect_1_to_2(collect_1_to_5(helper(Ex, it))));
		else if (*it == 25)
			all_variants.push_back(collect_1_to_2(collect_5_to_10(collect_1_to_5(collect_1_to_10(helper(Ex, it))))));
		else if (*it==50)
			all_variants.push_back(collect_1_to_2(collect_1_to_5(collect_1_to_10(collect_1_to_25(helper(Ex, it))))));
		else if (*it==100)
			all_variants.push_back(collect_1_to_2(collect_1_to_5(collect_1_to_10(collect_1_to_25(collect_1_to_50(helper(Ex, it)))))));
		it = Ex.end() - 1;
	}

}

vector<int>& Variants::helper(vector<int>&Ex,vector<int>::iterator it)
{
	switch (*it)
	{
	case 2:
		Ex.erase(it);
		Ex.push_back(1);
		Ex.push_back(1);
		return Ex;
	case 5:
		Ex.erase(it);
		Ex.push_back(2);
		Ex.push_back(2);
		Ex.push_back(1);
		sort(Ex.begin(), Ex.end(), greater<int>());
		return Ex;
	case 10:
		Ex.erase(it);
		Ex.push_back(5);
		Ex.push_back(5);
		sort(Ex.begin(), Ex.end(), greater<int>());
		return Ex;
	case 25:
		Ex.erase(it);
		Ex.push_back(10);
		Ex.push_back(10);
		Ex.push_back(5);
		sort(Ex.begin(), Ex.end(), greater<int>());
		return Ex;
	case 50:
		Ex.erase(it);
		Ex.push_back(25);
		Ex.push_back(25);
		sort(Ex.begin(), Ex.end(), greater<int>());
		return Ex;
	case 100:
		Ex.erase(it);
		Ex.push_back(50);
		Ex.push_back(50);
		sort(Ex.begin(), Ex.end(), greater<int>());
		return Ex;
	}
}
vector<int>& Variants::collect_1_to_2(vector<int>&Ex)
{
	int count = 0;
	vector<int>::iterator it = Ex.end() - 1;
	while (*it == 1)
	{
		count++;
		it--;
	}
	if (count < 2)
		return Ex;
	else if (count % 2 == 1)
		return collect_1_to_2_helper(Ex, count - 1, count / 2);
	else
		return collect_1_to_2_helper(Ex, count, count / 2);

}
vector<int>&Variants::collect_1_to_2_helper(vector<int>&Ex, int x, int y)
{
	for (int i = 0; i < x; i++)
		Ex.pop_back();
	for (int i = 0; i < y; i++)
		Ex.push_back(2);
	sort(Ex.begin(), Ex.end(), greater<int>());
	return Ex;
}
vector<int>&Variants::collect_1_to_5(vector<int>&Ex)
{
	return collect_helper(Ex, 5);
}
vector<int>& Variants::collect_1_to_10(vector<int>&Ex)
{
	return collect_helper(Ex, 10);
}
vector<int>&Variants::collect_1_to_25(vector<int>&Ex)
{
	return collect_helper(Ex, 25);
}
vector<int>&Variants::collect_1_to_50(vector<int>&Ex)
{
	return collect_helper(Ex, 50);
}
vector<int>&Variants::collect_5_to_10(vector<int>&Ex)
{
	int count = 0;
	vector<int>::iterator it = find(Ex.begin(), Ex.end(), 5);
	while (it != Ex.end())
	{
		Ex.erase(it);
		count++;
		it = find(Ex.begin(), Ex.end(), 5);
	}
	if (count ==0)
		return Ex;
	else if (count == 1)
	{
		Ex.push_back(5);
		sort(Ex.begin(), Ex.end(), greater<int>());
		return Ex;
	}
	else if (count % 2)
	{
		for (int i = 0; i < count / 2; i++)
		{
			Ex.push_back(10);
		}
		Ex.push_back(5);
		sort(Ex.begin(), Ex.end(), greater<int>());
		return Ex;
	}
	else
	{
		for (int i = 0; i < count / 2; i++)
		{
			Ex.push_back(10);
		}
		sort(Ex.begin(), Ex.end(), greater<int>());
		return Ex;
	}
	
}

vector<int>&Variants::collect_helper(vector<int>&Ex, int x)
{
	int count = 0;
	vector<int>::iterator it = Ex.end() - 1;
	while (*it == 1)
	{
		count++;
		it--;
	}
	if (count / x > 0)
	{
		for (int i = 0; i < count / x; i++)
		{
			for (int j = 0; j < x; j++)
				Ex.pop_back();
			Ex.push_back(x);
			sort(Ex.begin(), Ex.end(), greater<int>());
		}
		return Ex;
	}
	else
		return Ex;
}
void Variants::print()
{
	int x1= 1;
	for (int i = 0; i < all_variants.size(); i++)
	{
		cout << x1 << "   ";
		x1++;
		int x = 0;
		for (int j = 0; j < all_variants[i].size(); j++)
		{
			x += all_variants[i][j];
			cout << all_variants[i][j] << " ";
		}
		cout <<x<< endl << endl;
	}
}
void Variants::realize()
{
	this->set_sum();
	this->task_method(this->nominals.begin());
	this->print();
}