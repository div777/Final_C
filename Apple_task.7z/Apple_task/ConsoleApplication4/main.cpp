#include"header.h"
void main()
{
	Variants Ex;
	Ex.realize();
}