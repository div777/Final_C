#include"Card.h"
Card::Card()
{
	;
}
Card::Card(char Ex, string Ex1)
{
	suit = Ex;
	value = Ex1;
}

char Card::get_suit()
{
	return suit;
}

string& Card::get_value()
{
	return value;
}
void Card::set_suit_value(char a, string& b)
{
	suit = a;
	value = b;
}
