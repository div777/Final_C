/*Dear Employer
this is my first less or more serious project
and I know that not everything was written in a proper style
I can fix it, but it will take a while
However it works properly.
I will be glad to hear from you if you find me capable for the place you offer.
*/
#include"Game.h"
pair<char, string> kozir;
int index_suit = 0;
char mast[4] = { 3, 4, 5, 6 };
vector<pair<pair<int,int>,int>> priority_else(3);
int index_priority_else = 0;
char kozir_fin = 0;
int priority_you = 0;
int priority_comp = 0;
int card_your_move_val = 0;
int card_comp_move_val = 0;
int bella_comp = 0;
int bella_you = 0;
bool words_comp = 0;
char v_kozir1 = 0;
char v_kozir2 = 0;
char v_kozir3 = 0;
int size_hearts_comp = 0;
int size_diamonds_comp = 0;
int size_clubs_comp = 0;
int size_speads_comp = 0;
string A;
pair<char, string>card_comp_move;
pair<char, string>card_your_move;
ostream& operator << (ostream &Ex,const vector<Card>::iterator &Ex1)
{
	Ex << (*Ex1).get_suit() << " " << (*Ex1).get_value()<<endl;
	return Ex;
}
int helper1(char a)
{
	int x;
	switch (a)
	{
	case '7':
		x= 1;
		break;
	case '8':
		x= 2;
		break;
	case '9':
		x= 3;
		break;
	case '1':
		x = 4;
		break;
	case 'J':
		x = 5;
		break;
	case 'Q':
		x = 6;
		break;
	case 'K':
		x = 7;
		break;
	case 'A':
		x = 8;
	}
	return x;
}
int helper2(char a,bool x1)
{
	int x;
	if (!x1)
	{
		switch (a)
		{
		case '7':
			x = 1;
			break;
		case '8':
			x = 2;
			break;
		case '9':
			x = 3;
			break;
		case 'J':
			x = 4;
			break;
		case 'Q':
			x = 5;
			break;
		case 'K':
			x = 6;
			break;
		case '1':
			x = 7;
			break;
		case 'A':
			x = 8;
		}
	}
	else
	{
		switch (a)
		{
		case '7':
			x = 1;
			break;
		case '8':
			x = 2;
			break;
		case 'Q':
			x = 3;
			break;
		case 'K':
			x = 4;
			break;
		case '1':
			x = 5;
			break;
		case 'A':
			x = 6;
			break;
		case '9':
			x = 7;
			break;
		case 'J':
			x = 8;
		}
	}
	return x;
}
int helper_kozir(char a)
{
	int x;
	switch (a)
	{
	case '7':
		x = 1;
		break;
	case '8':
		x = 2;
	case 'Q':
		x = 3;
		break;
	case 'K':
		x = 4;
		break;
	case '1':
		x = 5;
		break;
	case 'A':
		x = 6;
		break;
	case'9':
		x = 7;
		break;
	case'J':
		x = 8;
	}
	return x;
}
bool compare(Card& Ex,Card& Ex1)
{
	return (Ex.get_suit() < Ex1.get_suit());
}
bool compare1(Card& Ex, Card& Ex1)
{
	int x1 = helper1(Ex.get_value().data()[0]);
	int x2 = helper1(Ex1.get_value().data()[0]);
	return (Ex.get_suit() == Ex1.get_suit()) &&(x1 < x2);
}
bool compare0(pair<char,int>&Ex,pair<char,int>&Ex1)
{
	return Ex.second < Ex1.second;
}
bool ras_pas_you_kryg_1()
{
	
	string x;
	regex a("1|2");
	cout << "1 Pass   2 Charge" << endl;
	while (1)
	{
		getline(cin, x);
		if (!regex_match(x,a))
			continue;
		else
			break;
	}
	if (x[0] == '1')
		return 0;
	else
	{
		kozir_fin = kozir.first;
		return 1;
	}
}
bool choice_you(bool x);
bool ras_pas_you_kryg2(bool turn)
{
	int x = 1;
	for (index_suit = 0; index_suit < 4; index_suit++)
	{
		if (mast[index_suit] == kozir.first)
			continue;
		else
			cout << x++ << " " << mast[index_suit] << endl;
	}
	if (!turn)
	{
		cout << x << " Pass" << endl << "Your word: ";
		return choice_you(turn);
	}
	else
		return choice_you(turn);
}
bool choice_you(bool turn)
{
	string x;
	regex a("1|2|3|4");
	regex b("1|2|3");
	if (!turn)
	{
		while (1)
		{
			getline(cin, x);
			
			if (regex_match(x,a))
				break;
			else
				continue;
		}
		switch (kozir.first)
		{
		case 3:
		{
			switch (x[0])
			{
			case '1':
				kozir_fin = mast[1];
				return 1;
			case '2':
				kozir_fin = mast[2];
				return 1;
			case '3':
				kozir_fin = mast[3];
				return 1;
			case '4':
				return 0;
			}
		}
		case 4:
		{
			switch (x[0])
			{
			case '1':
				kozir_fin = mast[0];
				return 1;
			case '2':
				kozir_fin = mast[2];
				return 1;
			case '3':
				kozir_fin = mast[3];
				return 1;
			case '4':
				return 0;
			}
		}
		case 5:
		{
			switch (x[0])
			{
			case '1':
				kozir_fin = mast[0];
				return 1;
			case '2':
				kozir_fin = mast[1];
				return 1;
			case '3':
				kozir_fin = mast[3];
				return 1;
			case '4':
				return 0;
			}
		}
		case 6:
		{
			switch (x[0])
			{
			case '1':
				kozir_fin = mast[0];
				return 1;
			case '2':
				kozir_fin = mast[1];
				return 1;
			case '3':
				kozir_fin = mast[2];
				return 1;
			case '4':
				return 0;
			}
		}
		}
	}
	else
	{
		while (1)
		{
			getline(cin, x);
			if (regex_match(x,b))
				break;
			else
				continue;
		}
		switch (kozir.first)
		{
		case 3:
		{
			switch (x[0])
			{
			case '1':
				kozir_fin = mast[1];
				break;
			case '2':
				kozir_fin = mast[2];
				break;
			case '3':
				kozir_fin = mast[3];
			}
			return 1;
		}
		case 4:
		{
			switch (x[0])
			{
			case '1':
				kozir_fin = mast[0];
				break;
			case '2':
				kozir_fin = mast[2];
				break;
			case '3':
				kozir_fin = mast[3];
			}
			return 1;
		}
		case 5:
		{
			switch (x[0])
			{
			case '1':
				kozir_fin = mast[0];
				break;
			case '2':
				kozir_fin = mast[1];
				break;
			case '3':
				kozir_fin = mast[3];
			}
			return 1;
		}
		case 6:
		{
			switch (x[0])
			{
			case '1':
				kozir_fin = mast[0];
				break;
			case '2':
				kozir_fin = mast[1];
				break;
			case '3':
				kozir_fin = mast[2];
			}
			return 1;
		}
		}
	}
}
bool compare2(Card &Ex)
{
	return (Ex.get_suit() == kozir.first) && (Ex.get_value() == "9");
}
bool compare3(Card&Ex)
{
	return(Ex.get_suit() == kozir.first) && (Ex.get_value() == "J");
}
bool compare4(Card &Ex)
{
	return Ex.get_suit() == mast[index_suit];
}
bool compare8(Card&Ex)
{
	return (Ex.get_suit() == kozir.first)&&(Ex.get_value() == "Q");
}
bool compare9(Card&Ex)
{
	return (Ex.get_suit() == kozir.first) && (Ex.get_value() == "K");
}
bool compare10(Card&Ex)
{
	return (Ex.get_suit() == mast[index_suit]) && (Ex.get_value() == "9");
}
bool compare11(Card&Ex)
{
	return (Ex.get_suit() == mast[index_suit]) && (Ex.get_value() == "J");
}
bool compare12(Card&Ex)
{
	return (Ex.get_suit() == mast[index_suit]) && (Ex.get_value() == "Q");
}
bool compare14(Card& Ex)
{
	return (Ex.get_suit() == mast[index_suit]) && (Ex.get_value() == "K");
}
bool compare15(pair<pair<int, int>,int>&Ex, pair<pair<int, int>,int>&Ex1)
{
	return Ex.first.second < Ex1.first.second;
}
bool compare16(Card& Ex)
{
	return (Ex.get_suit() == kozir.first) && (Ex.get_value() == "7");
}
int check_9_J_QK_main(vector<Card>& Ex)
{
	bool x1, x2, x3;
	if (find_if(Ex.begin(), Ex.end(), compare2) != Ex.end())
		x1 = 1;
	else
		x1=0;
	if (find_if(Ex.begin(), Ex.end(), compare3) != Ex.end())
		x2= 1;
	else
		x2= 0;
	if (find_if(Ex.begin(), Ex.end(), compare8) != Ex.end())
	{
		if (find_if(Ex.begin(), Ex.end(), compare9) != Ex.end())
			x3= 1;
		else
			x3= 0;
	}
	else
		x3= 0;
	if (!x1&&!x2&&!x3)
		return 0;
	if (x1&&!x2&&!x3)
		return 1;
	if (!x1&&x3&&!x2)
		return 2;
	if (!x1&&x2&&!x3)
		return 3;
	if (x1&&x3&&!x2)
		return 4;
	if (x1&&x2&&!x3)
		return 5;
	if (!x1&&x2&&x3)
		return 6;
	if (x1&&x2&&x3)
		return 7;
}
int check_9_J_QK_else_suit(vector<Card>&Ex)
{
	bool x1, x2, x3;
	if (find_if(Ex.begin(), Ex.end(), compare10) != Ex.end())
		x1 = 1;
	else
		x1 = 0;
	if (find_if(Ex.begin(), Ex.end(), compare11) != Ex.end())
		x2= 1;
	else
		x2= 0;
	if (find_if(Ex.begin(), Ex.end(), compare12) != Ex.end())
	{
		if (find_if(Ex.begin(), Ex.end(), compare14) != Ex.end())
			x3= 1;
		else
			x3= 0;
	}
	else
		x3= 0;
	if (!x1&&!x2&&!x3)
		return 0;
	if (x1&&!x2&&!x3)
		return 1;
	if (!x1&&x3&&!x2)
		return 2;
	if (!x1&&x2&&!x3)
		return 3;
	if (x1&&x3&&!x2)
		return 4;
	if (x1&&x2&&!x3)
		return 5;
	if (!x1&&x2&&x3)
		return 6;
	if (x1&&x2&&x3)
		return 7;
}
vector<Card>::iterator::difference_type&  count_hearts(vector<Card>&Ex)
{
	vector<Card>::iterator::difference_type Num = count_if(Ex.begin(), Ex.end(), compare4);
	return Num;
}
vector<Card>::iterator::difference_type & count_diamonds(vector<Card>&Ex)
{
	vector<Card>::iterator::difference_type Num = count_if(Ex.begin(), Ex.end(), compare4);
	return Num;
}
vector<Card>::iterator::difference_type & count_clubs(vector<Card>&Ex)
{
	vector<Card>::iterator::difference_type Num = count_if(Ex.begin(), Ex.end(), compare4);
	return Num;
}
vector<Card>::iterator::difference_type & count_speads(vector<Card>&Ex)
{
	vector<Card>::iterator::difference_type Num = count_if(Ex.begin(), Ex.end(), compare4);
	return Num;
}
int count_else(vector<Card>&Ex, char a)
{
	switch (a)
	{
	case 3:
		index_suit = 0;
		return count_hearts(Ex);
	case 4:
		index_suit = 1;
		return count_diamonds(Ex);
	case 5:
		index_suit = 2;
		return count_clubs(Ex);
	case 6:
		index_suit = 3;
		return count_speads(Ex);
	}
}
void compare_priority_helper(vector<Card>&Ex, vector<pair<pair<int, int>, int>>::iterator&it2)
{
	int ind = 0;
	for (index_suit = 0; index_suit < 4; index_suit++)
	{
		if (mast[index_suit] == kozir.first)
			continue;
		priority_else[ind].first.first = mast[index_suit];
		priority_else[ind].first.second = check_9_J_QK_else_suit(Ex);
		priority_else[ind++].second = count_else(Ex, mast[index_suit]);
	}
	index_suit = 0;
	vector<pair<pair<int, int>, int>>::iterator it = max_element(priority_else.begin(), priority_else.end(), compare15);
	vector<pair<pair<int, int>, int>>::iterator it1 = priority_else.begin();
	 it2 = it;
	for (; it1 < priority_else.end(); it1++)
	{
		if ((*it1).first.second == (*it).first.second)
		{
			if ((*it1).second >(*it).second)
				it2 = it1;
		}
	}
}
bool compare_priority(vector<Card>&Ex)
{
	
	int priority = check_9_J_QK_main(Ex);
	vector<pair<pair<int, int>, int>>::iterator it2;
	compare_priority_helper(Ex, it2);
	if (priority < (*it2).first.second)
	{
		if (priority == 1 && (count_else(Ex, kozir.first) > 3) && (*it2).first.second != 5)
		{
			kozir_fin = kozir.first;
			return 1;
		}
		kozir_fin = (*it2).first.first;
		return 0;
	}
	else if (priority >(*it2).second)
	{
		kozir_fin = kozir.first;
		return 1;
	}
	else if (priority == (*it2).second)
	{
		int ammount1, ammount2;

		ammount1 = count_else(Ex, kozir.first);
		ammount2 =(*it2).second;
		index_suit = 0;
		if (ammount1 > ammount2)
		{
			kozir_fin = kozir.first;
			return 1;
		}
		else
		{
			kozir_fin = (*it2).first.first;
			return 0;
		}
	}
}
bool ras_pas_comp_kryg_1_objaz(vector<Card>&Ex)
{
	vector<Card>::iterator it = find_if(Ex.begin(), Ex.end(), compare16);
	if (it != Ex.end())
	{
		vector<Card>Move(6);
		copy(Ex.begin(), Ex.end(), Move.begin());
		it = find_if(Move.begin(), Move.end(), compare16);
	   Card obj(kozir.first, kozir.second);
		swap(obj, *it);
		sort(Move.begin(), Move.end(), compare);
		sort(Move.begin(), Move.end(), compare1);
		return compare_priority(Move);
	}
	else
		return compare_priority(Ex);
	
}
void compare_priority_comp_cryg2_objaz(vector<Card>&Ex)
{
	vector<pair<pair<int, int>, int>>::iterator it2;
	compare_priority_helper(Ex,it2);
	kozir_fin = (*it2).first.first;
}
bool compare_priority_comp_cryg2_no_objaz(vector<Card>&Ex)
{
	vector<pair<pair<int, int>, int>>::iterator it2;
	compare_priority_helper(Ex,it2);
	if ((*it2).first.second >= 5)
	{
		kozir_fin = (*it2).first.first;
		return 1;
	}
	else
	{
		return 0;
	}
}
bool ras_pas_comp_cryg1_no_objaz(vector<Card>&Ex)
{
	vector<Card>::iterator it = find_if(Ex.begin(), Ex.end(), compare16);
	if (it != Ex.end())
	{
		vector<Card>Move(6);
		copy(Ex.begin(), Ex.end(), Move.begin());
		it = find_if(Move.begin(), Move.end(), compare16);
		Card obj(kozir.first, kozir.second);
		swap(obj, *it);
		sort(Move.begin(), Move.end(), compare);
		sort(Move.begin(), Move.end(), compare1);
		if (check_9_J_QK_main(Ex) >= 5)
		{
			kozir_fin = kozir.first;
			return 1;
		}
		else
			return 0;
	}
	else
	{
		if (check_9_J_QK_main(Ex) >= 5)
		{
			kozir_fin = kozir.first;
			return 1;
		}
		else
			return 0;
	}
}
bool ras_pas_comp_cryg2_no_objaz(vector<Card>&Ex)
{
	return  compare_priority_comp_cryg2_no_objaz(Ex);
}
bool check_50_7(vector<Card>&Ex)
{
	int x = count_else(Ex, kozir_fin);
	if (x>3)
	{
		vector<int>check_50;
		vector<Card>::iterator comp = Ex.begin();
		for (; comp < Ex.end(); comp++)
		{
			if ((*comp).get_suit() == kozir_fin)
			{
				check_50.push_back(helper1((*comp).get_value().data()[0]));
			}

		}
		if (check_50[0]==1&&check_50[1] == 2 && check_50[2] == 3 && check_50[3] == 4)
			return 0;
		else
			return 1;
	}
}
void split_suits_you(Game&Ex)
{
	vector<Card>::iterator it = Ex.get_hand_you().begin();
	while (it != Ex.get_hand_you().end() && (*it).get_suit() == 3)
		Ex.get_hearts_you().push_back(helper1((*it++).get_value().data()[0]));
	while (it != Ex.get_hand_you().end() && (*it).get_suit() == 4)
		Ex.get_diamonds_you().push_back(helper1((*it++).get_value().data()[0]));
	while (it != Ex.get_hand_you().end() && (*it).get_suit() == 5)
		Ex.get_clubs_you().push_back(helper1((*it++).get_value().data()[0]));
	while (it != Ex.get_hand_you().end() && (*it).get_suit() == 6)
		Ex.get_speads_you().push_back(helper1((*it++).get_value().data()[0]));
}
void split_suits_comp(Game&Ex)
{
	vector<Card>::iterator it = Ex.get_hand_comp().begin();
	while (it != Ex.get_hand_comp().end() && (*it).get_suit() == 3)
		Ex.get_hearts_comp().push_back(helper1((*it++).get_value().data()[0]));
while (it != Ex.get_hand_comp().end() && (*it).get_suit() == 4)
		Ex.get_diamonds_comp().push_back(helper1((*it++).get_value().data()[0]));
	while (it != Ex.get_hand_comp().end() && (*it).get_suit() == 5)
		Ex.get_clubs_comp().push_back(helper1((*it++).get_value().data()[0]));
	while (it != Ex.get_hand_comp().end() && (*it).get_suit() == 6)
		Ex.get_speads_comp().push_back(helper1((*it++).get_value().data()[0]));
}
bool helper3(vector<int>&Ex, vector<int>& A)
{
	vector<int>::iterator it = search(Ex.begin(),Ex.end(),A.begin(),A.end());
	if (it == Ex.end())
		return 0;
	else
		return 1;
}
void set_terts_comp(Game &Ex, int a, int b, int c)
{
	if (!Ex.get_comp_20_1().size())
		Ex.set_comp_20_1(Ex.get_comp_20_1(), a, b);
	else if (!Ex.get_comp_20_2().size())
		Ex.set_comp_20_2(Ex.get_comp_20_2(), a, b);
	else if (!Ex.get_comp_20_3().size())
		Ex.set_comp_20_3(Ex.get_comp_20_3(), a, b);

	if (Ex.get_top_20_comp() >= c)
		;
	else
		Ex.set_top_20_comp(c);
}

void set_2_terts_comp(Game&Ex, int a, int b, int c, int d)
{
	if (!Ex.get_comp_20_1().size())
	{
		Ex.set_comp_20_1(Ex.get_comp_20_1(), a, b);
		Ex.set_comp_20_2(Ex.get_comp_20_2(), a, c);
	}
	else
	{
		Ex.set_comp_20_2(Ex.get_comp_20_2(), a, b);
		Ex.set_comp_20_3(Ex.get_comp_20_3(), a, c);
	}
	if (Ex.get_top_20_comp() >= d)
		;
	else
		Ex.set_top_20_comp(d);
}
void set_50_comp(Game&Ex, int a, int b, int c)
{
	if (!Ex.get_comp_50_1().size())
		Ex.set_comp_50_1(Ex.get_comp_50_1(), a, b);
	else
		Ex.set_comp_50_2(Ex.get_comp_50_2(), a, b);

	if (Ex.get_top_50_comp() >= c)
		;
	else
		Ex.set_top_50_comp(c);
}
void set_50_20_comp(Game &Ex, int a, int b, int c, int d, int e)
{
	Ex.set_comp_50_1(Ex.get_comp_50_1(), a, b);
	Ex.set_top_50_comp(d);
	if (!Ex.get_comp_20_1().size())
		Ex.set_comp_20_1(Ex.get_comp_20_1(), a, c);
	else
		Ex.set_comp_20_2(Ex.get_comp_20_2(), a, c);
	if (Ex.get_top_20_comp() >= e)
		;
	else
    	Ex.set_top_20_comp(e);
}
void set_terts_you(Game &Ex, int a, int b, int c)
{
	if (!Ex.get_you_20_1().size())
		Ex.set_you_20_1(Ex.get_you_20_1(), a, b);
	else if (!Ex.get_you_20_2().size())
		Ex.set_you_20_2(Ex.get_you_20_2(), a, b);
	else if (!Ex.get_you_20_3().size())
		Ex.set_you_20_3(Ex.get_you_20_3(), a, b);

	if (Ex.get_top_20_you() >= c)
		;
	else
		Ex.set_top_20_you(c);
}
void set_2_terts_you(Game&Ex, int a, int b, int c, int d)
{
	if (!Ex.get_you_20_1().size())
	{
		Ex.set_you_20_1(Ex.get_you_20_1(), a, b);
		Ex.set_you_20_2(Ex.get_you_20_2(), a, c);
	}
	else
	{
		Ex.set_you_20_2(Ex.get_you_20_2(), a, b);
		Ex.set_you_20_3(Ex.get_you_20_3(), a, c);
	}
	if (Ex.get_top_20_you() >= d)
		;
	else
		Ex.set_top_20_you(d);
}
void set_50_you(Game&Ex, int a, int b, int c)
{
	if (!Ex.get_you_50_1().size())
		Ex.set_you_50_1(Ex.get_you_50_1(), a, b);
	else
		Ex.set_you_50_2(Ex.get_you_50_2(), a, b);

	if (Ex.get_top_50_you() >= c)
		;
	else
		Ex.set_top_50_you(c);
}
void set_50_20_you(Game &Ex, int a, int b, int c, int d, int e)
{
	Ex.set_you_50_1(Ex.get_you_50_1(), a, b);
	Ex.set_top_50_you(d);
	if (!Ex.get_you_20_1().size())
		Ex.set_you_20_1(Ex.get_you_20_1(), a, c);
	else
		Ex.set_you_20_2(Ex.get_you_20_2(), a, c);
	if (Ex.get_top_20_you() >= e)
		;
	else
	  Ex.set_top_20_you(e);
}
int helper4(Game&Ex, vector<int>&mast,
	vector<int>& var50_1, vector<int>&var50_2, vector<int>&var50_3, vector<int>&var50_4, vector<int>&var50_5,
	vector<int>&var20_1, vector<int>&var20_2, vector<int>&var20_3, vector<int>&var20_4, vector<int>&var20_5, vector<int>&var20_6, int x, bool y)
{
	int priority_middle;
	bool a = 0;
	bool b = 0;
	bool c = 0;
	bool d = 0;
	bool e = 0;
	bool f = 0;
	bool g = 0;
	bool h = 0;
	bool i = 0;
	bool j = 0;
	bool k = 0;
	if (mast.size() > 3)
	{
		a = helper3(mast, var50_1);
		b = helper3(mast, var50_2);
		c = helper3(mast, var50_3);
		d = helper3(mast, var50_4);
		e = helper3(mast, var50_5);
		f = helper3(mast, var20_1);
		g = helper3(mast, var20_2);
		h = helper3(mast, var20_3);
		i = helper3(mast, var20_4);
		j = helper3(mast, var20_5);
		k = helper3(mast, var20_6);
		switch (y)
		{
		case 0:
		{
			if (a&&!b&&!c&&!d&&!e)
			{
				set_50_you(Ex,x, 1, 10);
				priority_middle = 4;
			}
			 if (!a&&b&&!c&&!d&&!e)
			{
				set_50_you(Ex, x, 2, 11);
				priority_middle = 4;
			}
			 if (!a&&!b&&c&&!d&&!e)
			{
				set_50_you(Ex, x, 3, 12);
				priority_middle = 4;
			}
			 if (!a&&!b&&!c&&d&&!e)
			{
				set_50_you(Ex, x, 4, 13);
				priority_middle = 4;
			}
		  if (!a&&!b&&!c&&!d&&e)
			{
				set_50_you(Ex, x, 5, 14);
				priority_middle = 4;
			}
			 if (!a&&!b&&!c&&!d&&!e&&f&&!g&&!h&&!i&&!j&&!k)
			{
				set_terts_you(Ex, x, 1, 9);
				priority_middle = 1;
			}
		   if (!a&&!b&&!c&&!d&&!e&&!f&&g&&!h&&!i&&!j&&!k)
			{
				set_terts_you(Ex, x, 2, 10);
				priority_middle = 1;
			}
			 if (!a&&!b&&!c&&!d&&!e&&!f&&!g&&h&&!i&&!j&&!k)
			{
				set_terts_you(Ex, x, 3, 11);
				priority_middle = 1;
			}
			 if (!a&&!b&&!c&&!d&&!e&&!f&&!g&&!h&&i&&!j&&!k)
			{
				set_terts_you(Ex, x, 4, 12);
				priority_middle = 1;
			}
			 if (!a&&!b&&!c&&!d&&!e&&!f&&!g&&!h&&!i&&j&&!k)
			{
				set_terts_you(Ex, x, 5, 13);
				priority_middle = 1;
			}
			 if (!a&&!b&&!c&&!d&&!e&&!f&&!g&&!h&&!i&&!j&&k)
			{
				set_terts_you(Ex, x, 6, 14);
				priority_middle = 1;
			}
			 if (a&&b&&!c&&!d&&!e)
			{
				set_50_you(Ex, x, 2, 11);
				priority_middle = 4;
			}
			 if (!a&&b&&c&&!d&&!e)
			{
				set_50_you(Ex, x, 3, 12);
				priority_middle = 4;
				
			}
			 if (!a&&!b&&c&&d&&!e)
			{
				set_50_you(Ex, x, 4, 13);
				priority_middle = 4;
				
			}
			 if (!a&&!b&&!c&&d&&e)
			{
				set_50_you(Ex, x, 5, 14);
				priority_middle = 4;
			}
			 if (a&&c&&!d&&!e)
			{
				set_50_you(Ex, x, 3, 12);
				priority_middle = 4;
			}
			 if (!a&&b&&d&&!e)
			{
				set_50_you(Ex, x, 4, 13);
				priority_middle = 4;
			}
			 if (!a&&!b&&c&&e)
			{
				set_50_you(Ex, x, 5, 14);
				priority_middle = 4;
			}
			 if (a&&d&&!e)
			{
				set_50_20_you(Ex, x, 4, 1, 13, 9);
				priority_middle = 5;
			}
			 if (b&&e&&!a)
			{
				set_50_20_you(Ex, x, 5, 2, 14, 10);
				priority_middle = 5;
			}
			 if (!a&&!b&&!c&&!d&&!e&&f&&j)
			{
				set_2_terts_you(Ex, x, 1, 5, 13);
				priority_middle = 2;
			}
			 if (!a&&!b&&!c&&!d&&!e&&f&&k)
			{
				set_2_terts_you(Ex, x, 1, 6, 14);
				priority_middle = 2;
			}
		   if (!a&&!b&&!c&&!d&&!e&&g&&k)
			{
				set_2_terts_you(Ex, x, 2, 6, 14);
				priority_middle = 2;
			}
		   if (a&&e)
			{
				Ex.set_you_50_1(Ex.get_you_50_1(), x, 1);
				Ex.set_you_50_2(Ex.get_you_50_2(), x, 5);
				Ex.set_top_50_you(14);
				priority_middle = 8;
			}
			 if (!a&&!b&&!c&&!d&&!e&&!f&&!g&&!h&&!i&&!j&&!k)
				priority_middle = 0;
			return priority_middle;
		}
		case 1:
		{
			if (a&&!b&&!c&&!d&&!e)
			{
				set_50_comp(Ex, x, 1, 10);
				priority_middle = 4;
			}
		 if (!a&&b&&!c&&!d&&!e)
			{
				set_50_comp(Ex, x, 2, 11);
				priority_middle = 4;
			}
		 if (!a&&!b&&c&&!d&&!e)
			{
				set_50_comp(Ex, x, 3, 12);
				priority_middle = 4;
			}
		  if (!a&&!b&&!c&&d&&!e)
			{
				set_50_comp(Ex, x, 4, 13);
				priority_middle = 4;
			}
		   if (!a&&!b&&!c&&!d&&e)
			{
				set_50_comp(Ex, x, 5, 14);
				priority_middle = 4;
			}
		   if (!a&&!b&&!c&&!d&&!e&&f&&!g&&!h&&!i&&!j&&!k)
			{
				set_terts_comp(Ex, x, 1, 9);
				priority_middle = 1;
			}
		   if (!a&&!b&&!c&&!d&&!e&&!f&&g&&!h&&!i&&!j&&!k)
			{
				set_terts_comp(Ex, x, 2, 10);
				priority_middle = 1;
			}
		   if (!a&&!b&&!c&&!d&&!e&&!f&&!g&&h&&!i&&!j&&!k)
			{
				set_terts_comp(Ex, x, 3, 11);
				priority_middle = 1;
			}
			 if (!a&&!b&&!c&&!d&&!e&&!f&&!g&&!h&&i&&!j&&!k)
			{
				set_terts_comp(Ex, x, 4, 12);
				priority_middle = 1;
			}
			 if (!a&&!b&&!c&&!d&&!e&&!f&&!g&&!h&&!i&&j&&!k)
			{
				set_terts_comp(Ex, x, 5, 13);
				priority_middle = 1;
			}
			 if (!a&&!b&&!c&&!d&&!e&&!f&&!g&&!h&&!i&&!j&&k)
			{
				set_terts_comp(Ex, x, 6, 14);
				priority_middle = 1;
			}
			 if (a&&b&&!c&&!d&&!e)
			{
				set_50_comp(Ex, x, 2, 11);
				priority_middle = 4;
			}
			 if (!a&&b&&c&&!d&&!e)
			{
				set_50_comp(Ex, x, 3, 12);
				priority_middle = 4;
			}
			 if (!a&&!b&&c&&d&&!e)
			{
				set_50_comp(Ex, x, 4, 13);
				priority_middle = 4;
			}
			 if (!a&&!b&&!c&&d&&e)
			{
				set_50_comp(Ex, x, 5, 14);
				priority_middle = 4;
			}
			 if (a&&c&&!d&&!e)
			{
				set_50_comp(Ex, x, 3, 12);
				priority_middle = 4;
			}
			 if (!a&&b&&d&&!e)
			{
				set_50_comp(Ex, x, 4, 13);
				priority_middle = 4;
			}
			 if (!a&&!b&&c&&e)
			{
				set_50_comp(Ex, x, 5, 14);
				priority_middle = 4;
			}
			 if (a&&d&&!e)
			{
				set_50_20_comp(Ex, x, 4, 1, 13, 9);
				priority_middle = 5;
			}
			 if (b&&e&&!a)
			{
				set_50_20_comp(Ex, x, 5, 2, 14, 10);
				priority_middle = 5;
			}
			 if (!a&&!b&&!c&&!d&&!e&&f&&j)
			{
				set_2_terts_comp(Ex, x, 1, 5, 13);
				priority_middle = 2;
			}
		    if (!a&&!b&&!c&&!d&&!e&&f&&k)
			{
				set_2_terts_comp(Ex, x, 1, 6, 14);
				priority_middle = 2;
			}
			 if (!a&&!b&&!c&&!d&&!e&&g&&k)
			{
				set_2_terts_comp(Ex, x, 2, 6, 14);
				priority_middle = 2;
			}
		 if (a&&e)
			{
				Ex.set_comp_50_1(Ex.get_comp_50_1(), x, 1);
				Ex.set_comp_50_2(Ex.get_comp_50_2(), x, 5);
				Ex.set_top_50_comp(14);
				priority_middle = 8;
			}
		 if (!a&&!b&&!c&&!d&&!e&&!f&&!g&&!h&&!i&&!j&&!k)
				priority_middle = 0;
			return priority_middle;
		}
		}
	}
	else if (mast.size() == 3)
	{
		f = helper3(mast, var20_1);
		g = helper3(mast, var20_2);
		h = helper3(mast, var20_3);
		i = helper3(mast, var20_4);
		j = helper3(mast, var20_5);
		k = helper3(mast, var20_6);
		switch (y)
		{
		case 0:
		{
			if (f)
			{
				set_terts_you(Ex, x, 1, 9);
				priority_middle = 1;
			}
			if (g)
			{
				set_terts_you(Ex, x, 2, 10);
				priority_middle = 1;
			}
			if (h)
			{
				set_terts_you(Ex, x, 3, 11);
				priority_middle = 1;
			}
			if (i)
			{
				set_terts_you(Ex, x, 4, 12);
				priority_middle = 1;
			}
			if (j)
			{
				set_terts_you(Ex, x, 5, 13);
				priority_middle = 1;
			}
			if (k)
			{
				set_terts_you(Ex, x, 6, 14);
				priority_middle = 1;
			}
			if (!f&&!g&&!h&&!i&&!j&&!k)
				priority_middle = 0;
			return priority_middle;
		}
		case 1:
			if (f)
			{
				set_terts_comp(Ex, x, 1, 9);
				priority_middle = 1;
			}
			
			if (g)
			{
				set_terts_comp(Ex, x, 2, 10);
				priority_middle = 1;
			}
			if (h)
			{
				set_terts_comp(Ex, x, 3, 11);
				priority_middle = 1;
			}
			if (i)
			{
				set_terts_comp(Ex, x, 4, 12);
				priority_middle = 1;
			}
			if (j)
			{
				set_terts_comp(Ex, x, 5, 13);
				priority_middle = 1;
			}
			if (k)
			{
				set_terts_comp(Ex, x, 6, 14);
				priority_middle = 1;
			}
			if (!f&&!g&&!h&&!i&&!j&&!k)
				priority_middle = 0;
			return priority_middle;
		}
	}
	else
		return 0;
}

void show_terts(vector<Card>&Ex)
{
	vector<Card>::iterator it = Ex.begin();
	cout << (*it).get_suit() << " ";
	for (; it != Ex.end(); it++)
		cout << (*it).get_value();
	cout << endl;
}
void show_2_terts(vector<Card>&Ex1, vector<Card>&Ex2)
{
	show_terts(Ex1);
	show_terts(Ex2);
	cout << endl;
}
void show_3_terts(vector<Card>&Ex1, vector<Card>&Ex2, vector<Card>&Ex3)
{
	show_terts(Ex1);
	show_terts(Ex2);
	show_terts(Ex3);
	cout << endl;
}
void clear_50_20_you_comp(Game&Ex)
{
	if (Ex.get_you_20_1().size())
		Ex.get_you_20_1().erase(Ex.get_you_20_1().begin(), Ex.get_you_20_1().end());
	if (Ex.get_you_20_2().size())
		Ex.get_you_20_2().erase(Ex.get_you_20_2().begin(), Ex.get_you_20_2().end());
	if (Ex.get_you_20_3().size())
		Ex.get_you_20_3().erase(Ex.get_you_20_3().begin(), Ex.get_you_20_3().end());
	if (Ex.get_you_50_1().size())
		Ex.get_you_50_1().erase(Ex.get_you_50_1().begin(), Ex.get_you_50_1().end());
	if (Ex.get_you_50_2().size())
		Ex.get_you_50_2().erase(Ex.get_you_50_2().begin(), Ex.get_you_50_2().end());
	if (Ex.get_comp_20_1().size())
		Ex.get_comp_20_1().erase(Ex.get_comp_20_1().begin(), Ex.get_comp_20_1().end());
	if (Ex.get_comp_20_2().size())
		Ex.get_comp_20_2().erase(Ex.get_comp_20_2().begin(), Ex.get_comp_20_2().end());
	if (Ex.get_comp_20_3().size())
		Ex.get_comp_20_3().erase(Ex.get_comp_20_3().begin(), Ex.get_comp_20_3().end());
	if (Ex.get_comp_50_1().size())
		Ex.get_comp_50_1().erase(Ex.get_comp_50_1().begin(), Ex.get_comp_50_1().end());
	if (Ex.get_comp_50_2().size())
		Ex.get_comp_50_2().erase(Ex.get_comp_50_2().begin(), Ex.get_comp_50_2().end());
}
void show_words(int you, int comp, bool turn, Game&Ex)
{
	if (you == comp)
	{
		if (you == 1)
		{
			if (Ex.get_top_20_you() > Ex.get_top_20_comp())
				show_terts(Ex.get_you_20_1());
			else if (Ex.get_top_20_you() < Ex.get_top_20_comp())
				show_terts(Ex.get_comp_20_1());
			else if (Ex.get_top_20_you() == Ex.get_top_20_comp())
			{
				if (!turn)
					show_terts(Ex.get_you_20_1());
				else
					show_terts(Ex.get_comp_20_1());
			}
		}
		if (you == 2)
		{
			if (Ex.get_top_20_you() > Ex.get_top_20_comp())
				show_2_terts(Ex.get_you_20_1(), Ex.get_you_20_2());
			else if (Ex.get_top_20_you() < Ex.get_top_20_comp())
				show_2_terts(Ex.get_comp_20_1(), Ex.get_comp_20_2());
			else if (Ex.get_top_20_you() == Ex.get_top_20_comp())
			{
				if (!turn)
					show_2_terts(Ex.get_you_20_1(), Ex.get_you_20_2());
				else
					show_2_terts(Ex.get_comp_20_1(), Ex.get_comp_20_2());
			}
		}
		if (you == 3)
		{
			if (Ex.get_top_20_you() > Ex.get_top_20_comp())
				show_3_terts(Ex.get_you_20_1(), Ex.get_you_20_2(), Ex.get_you_20_3());
			else if (Ex.get_top_20_you() < Ex.get_top_20_comp())
				show_3_terts(Ex.get_comp_20_1(), Ex.get_comp_20_2(), Ex.get_comp_20_3());
			else if (Ex.get_top_20_you() == Ex.get_top_20_comp())
			{
				if (!turn)
					show_3_terts(Ex.get_you_20_1(), Ex.get_you_20_2(), Ex.get_you_20_3());
				else
					show_3_terts(Ex.get_comp_20_1(), Ex.get_comp_20_2(), Ex.get_comp_20_3());
			}
		}
		if (you == 4)
		{
			if (Ex.get_top_50_you() > Ex.get_top_50_comp())
				show_terts(Ex.get_you_50_1());
			else if (Ex.get_top_50_you() < Ex.get_top_50_comp())
				show_terts(Ex.get_comp_50_1());
			else if (Ex.get_top_50_you() == Ex.get_top_50_comp())
			{
				if (!turn)
					show_terts(Ex.get_you_50_1());
				else
					show_terts(Ex.get_comp_50_1());
			}
		}
		if (you == 5)
		{
			if (Ex.get_top_50_you() > Ex.get_top_50_comp())
				show_2_terts(Ex.get_you_50_1(), Ex.get_you_20_1());
			else if (Ex.get_top_50_you() < Ex.get_top_50_comp())
				show_2_terts(Ex.get_comp_50_1(), Ex.get_comp_20_1());
			else if (Ex.get_top_50_you() == Ex.get_top_50_comp())
			{
				if (Ex.get_top_20_you() > Ex.get_top_20_comp())
					show_2_terts(Ex.get_you_50_1(), Ex.get_you_20_1());
				if (Ex.get_top_20_you() < Ex.get_top_20_comp())
					show_2_terts(Ex.get_comp_50_1(), Ex.get_comp_20_1());
				if (Ex.get_top_20_you() == Ex.get_top_20_comp())
				{
					if (!turn)
						show_2_terts(Ex.get_you_50_1(), Ex.get_you_20_1());
					else
						show_2_terts(Ex.get_comp_50_1(), Ex.get_comp_20_1());
				}
			}
		}
		if (you == 6)
		{
			if (Ex.get_top_50_you() > Ex.get_top_50_comp())
				show_3_terts(Ex.get_you_50_1(), Ex.get_you_20_1(), Ex.get_you_20_2());
			else if (Ex.get_top_50_you() < Ex.get_top_50_comp())
				show_3_terts(Ex.get_comp_50_1(), Ex.get_comp_20_1(), Ex.get_comp_20_2());
			else if (Ex.get_top_50_you() == Ex.get_top_50_comp())
			{
				if (Ex.get_top_20_you() > Ex.get_top_20_comp())
					show_3_terts(Ex.get_you_50_1(), Ex.get_you_20_1(), Ex.get_you_20_2());
				if (Ex.get_top_20_you() < Ex.get_top_20_comp())
					show_3_terts(Ex.get_comp_50_1(), Ex.get_comp_20_1(), Ex.get_comp_20_2());
				if (Ex.get_top_20_you() == Ex.get_top_20_comp())
				{
					if (!turn)
						show_3_terts(Ex.get_you_50_1(), Ex.get_you_20_1(), Ex.get_you_20_2());
					else
						show_3_terts(Ex.get_comp_50_1(), Ex.get_comp_20_1(), Ex.get_comp_20_2());
				}
			}
		}
		if (you == 8)
		{
			if (Ex.get_top_50_you() > Ex.get_top_50_comp())
				show_2_terts(Ex.get_you_50_1(), Ex.get_you_50_2());
			else if (Ex.get_top_50_you() < Ex.get_top_50_comp())
				show_2_terts(Ex.get_comp_50_1(), Ex.get_comp_50_2());
			else if (Ex.get_top_50_you() == Ex.get_top_50_comp())
			{
				if (!turn)
					show_2_terts(Ex.get_you_50_1(), Ex.get_you_50_2());
				else
					show_2_terts(Ex.get_comp_50_1(), Ex.get_comp_50_2());
			}
		}
	}
		else if (you > comp)
		{
			if (you == 4 && comp == 3)
			{
				show_3_terts(Ex.get_comp_20_1(), Ex.get_comp_20_2(), Ex.get_comp_20_3());
			}
			else
			{
				switch (you)
				{
				case 1:
					show_terts(Ex.get_you_20_1());
					break;
				case 2:
					show_2_terts(Ex.get_you_20_1(), Ex.get_you_20_2());
					break;
				case 3:
					show_3_terts(Ex.get_you_20_1(), Ex.get_you_20_2(), Ex.get_you_20_3());
					break;
				case 4:
					show_terts(Ex.get_you_50_1());
					break;
				case 5:
					show_2_terts(Ex.get_you_50_1(), Ex.get_you_20_1());
					break;
				case 6:
					show_3_terts(Ex.get_you_50_1(), Ex.get_you_20_1(), Ex.get_you_20_2());
					break;
				case 8:
					show_2_terts(Ex.get_you_50_1(), Ex.get_you_50_2());
				}
			}
		}
		else if (you < comp)
		{
			if (you == 3 && comp == 4)
				show_3_terts(Ex.get_you_20_1(), Ex.get_you_20_2(), Ex.get_you_20_3());
			else
			{
				switch (comp)
				{
				case 1:
					show_terts(Ex.get_comp_20_1());
					break;
				case 2:
					show_2_terts(Ex.get_comp_20_1(), Ex.get_comp_20_2());
					break;
				case 3:
					show_3_terts(Ex.get_comp_20_1(), Ex.get_comp_20_2(), Ex.get_comp_20_3());
					break;
				case 4:
					show_terts(Ex.get_comp_50_1());
					break;
				case 5:
					show_2_terts(Ex.get_comp_50_1(), Ex.get_comp_20_1());
					break;
				case 6:
					show_3_terts(Ex.get_comp_50_1(), Ex.get_comp_20_1(), Ex.get_comp_20_2());
					break;
				case 8:
					show_2_terts(Ex.get_comp_50_1(), Ex.get_comp_50_2());
				}
			}

		}
}
void check_words(vector<int>&Ex1, vector<int>&Ex2, vector<int>&Ex3, vector<int>&Ex4,vector<int>&Ex5, vector<int>&Ex6, vector<int>&Ex7, vector<int>&Ex8,Game&Ex9)
{
	vector<int>var50_1(4);
	vector<int>var50_2(4);
	vector<int>var50_3(4);
	vector<int>var50_4(4);
	vector<int>var50_5(4);
	vector<int>var20_1(3);
	vector<int>var20_2(3);
	vector<int>var20_3(3);
	vector<int>var20_4(3);
	vector<int>var20_5(3);
	vector<int>var20_6(3);
	var50_1.assign({ 1, 2, 3, 4 });
	var50_2.assign({ 2, 3, 4, 5 });
	var50_3.assign({ 3, 4, 5, 6 });
	var50_4.assign({ 4, 5, 6, 7 });
	var50_5.assign({ 5, 6, 7, 8 });
	var20_1.assign({ 1, 2, 3 });
	var20_2.assign({ 2, 3, 4 });
	var20_3.assign({ 3, 4, 5 });
	var20_4.assign({ 4, 5, 6 });
	var20_5.assign({ 5, 6, 7 });
	var20_6.assign({ 6, 7, 8 });
	int priority_hearts_you = helper4(Ex9, Ex1, var50_1, var50_2, var50_3, var50_4, var50_5, var20_1, var20_2, var20_3, var20_4, var20_5, var20_6, 3, 0);
	int priority_diamonds_you = helper4(Ex9, Ex2, var50_1, var50_2, var50_3, var50_4, var50_5, var20_1, var20_2, var20_3, var20_4, var20_5, var20_6, 4, 0);
	int priority_clubs_you = helper4(Ex9, Ex3, var50_1, var50_2, var50_3, var50_4, var50_5, var20_1, var20_2, var20_3, var20_4, var20_5, var20_6, 5, 0);
	int priority_speads_you = helper4(Ex9, Ex4, var50_1, var50_2, var50_3, var50_4, var50_5, var20_1, var20_2, var20_3, var20_4, var20_5, var20_6, 6, 0);
	int priority_hearts_comp = helper4(Ex9, Ex5, var50_1, var50_2, var50_3, var50_4, var50_5, var20_1, var20_2, var20_3, var20_4, var20_5, var20_6, 3, 1);
	int priority_diamonds_comp = helper4(Ex9, Ex6, var50_1, var50_2, var50_3, var50_4, var50_5, var20_1, var20_2, var20_3, var20_4, var20_5, var20_6, 4, 1);
	int priority_clubs_comp = helper4(Ex9, Ex7, var50_1, var50_2, var50_3, var50_4, var50_5, var20_1, var20_2, var20_3, var20_4, var20_5, var20_6, 5, 1);
	int priority_speads_comp = helper4(Ex9, Ex8, var50_1, var50_2, var50_3, var50_4, var50_5, var20_1, var20_2, var20_3, var20_4, var20_5, var20_6, 6, 1);
	Ex9.set_priority_you(priority_hearts_you + priority_diamonds_you + priority_clubs_you + priority_speads_you);
	Ex9.set_priority_comp(priority_hearts_comp + priority_diamonds_comp + priority_clubs_comp + priority_speads_comp);

}
bool check_deb_you_helper(vector<int>&Ex,vector<int>&seq)
{
	if (Ex.size() == 6)
		return helper3(Ex, seq);
	else
		return 0;
}
bool check_deb_you(Game&Ex,char a)
{
	vector<int>seq(6);
	seq.assign({ 3, 4, 5, 6, 7, 8 });
	switch (a)
	{
	case 3:
		return check_deb_you_helper(Ex.get_hearts_you(),seq);
	case 4:
		return check_deb_you_helper(Ex.get_diamonds_you(), seq);
	case 5:
		return check_deb_you_helper(Ex.get_clubs_you(), seq);
	case 6:
		return check_deb_you_helper(Ex.get_speads_you(), seq);
	}
}
bool check_deb_comp(Game&Ex, char a)
{
	vector<int>seq(6);
	seq.assign({ 3, 4, 5, 6, 7, 8 });
	switch (a)
	{
	case 3:
		return check_deb_you_helper(Ex.get_hearts_comp(), seq);
	case 4:
		return check_deb_you_helper(Ex.get_diamonds_comp(), seq);
	case 5:
		return check_deb_you_helper(Ex.get_clubs_comp(), seq);
	case 6:
		return check_deb_you_helper(Ex.get_speads_comp(), seq);
	}
}
void clear_suits_you(Game&Ex)
{
	if (Ex.get_hearts_you().size())
	Ex.get_hearts_you().erase(Ex.get_hearts_you().begin(), Ex.get_hearts_you().end());
	if (Ex.get_diamonds_you().size())
	Ex.get_diamonds_you().erase(Ex.get_diamonds_you().begin(), Ex.get_diamonds_you().end());
	if (Ex.get_clubs_you().size())
	Ex.get_clubs_you().erase(Ex.get_clubs_you().begin(), Ex.get_clubs_you().end());
	if (Ex.get_speads_you().size())
	Ex.get_speads_you().erase(Ex.get_speads_you().begin(), Ex.get_speads_you().end());
}
void clear_suits_comp(Game&Ex)
{
	if (Ex.get_hearts_comp().size())
	Ex.get_hearts_comp().erase(Ex.get_hearts_comp().begin(), Ex.get_hearts_comp().end());
	if (Ex.get_diamonds_comp().size())
	Ex.get_diamonds_comp().erase(Ex.get_diamonds_comp().begin(), Ex.get_diamonds_comp().end());
	if (Ex.get_clubs_comp().size())
	Ex.get_clubs_comp().erase(Ex.get_clubs_comp().begin(), Ex.get_clubs_comp().end());
	if (Ex.get_speads_comp().size())
	Ex.get_speads_comp().erase(Ex.get_speads_comp().begin(), Ex.get_speads_comp().end());
}
bool pre_words_helper(int x, int y, bool turn, Game&Ex)
{
	if (!turn)
	{
		cout << "Make a move and he'll show it." << endl;
		return 1;
	}
	else
	{
		show_words(x, y, turn, Ex);
		return 0;
	}
}
bool pre_words(int x, int y, bool turn, Game &Ex,int & count_you,int &count_comp)
{
	if (x == y)
	{
		if (x == 0)
			cout << "Slov net ne y kogo.\n";
		if (x == 1)
		{
			if (Ex.get_top_20_you() > Ex.get_top_20_comp())
			{
				cout << "You have a hier terts:";
				count_you = 20;
				show_words(x, y, turn, Ex);
				return 0;
			}
			else if (Ex.get_top_20_you() < Ex.get_top_20_comp())
			{
				cout << "Comp has a hier terts: ";
				count_comp = 20;
				return pre_words_helper(x, y, turn, Ex);
			}
			else if (Ex.get_top_20_you() == Ex.get_top_20_comp())
			{
				if (!turn)
				{
					cout << "Vash terts po krygy first: ";
					count_you = 20;
					show_words(x, y, turn, Ex);
					return 0;
				}
				else
				{
					cout << "Sorry comp's terts is first po krygy: ";
					count_comp = 20;
					return pre_words_helper(x, y, turn, Ex);
				}
			}
		}
		if (x == 2)
		{
			if (Ex.get_top_20_you() > Ex.get_top_20_comp())
			{
				cout << "You have hier 2 terts: ";
				count_you = 40;
				show_words(x, y, turn, Ex);
				return 0;
			}
			else if (Ex.get_top_20_you() < Ex.get_top_20_comp())
			{
				cout << "Comp has hier 2 terts: ";
				count_comp = 40;
				return pre_words_helper(x, y, turn, Ex);
			}
			else if (Ex.get_top_20_you() == Ex.get_top_20_comp())
			{
				if (!turn)
				{
					cout << "VashIb 2 terts po krygy first: ";
					count_you = 40;
					show_words(x, y, turn, Ex);
					return 0;
				}
				else
				{
					cout << "Sorry comp's 2 terts are first po krygy: ";
					count_comp = 40;
					show_words(x, y, turn, Ex);
					return 0;
				}
			}
		}
		if (x == 3)
		{
			if (Ex.get_top_20_you() > Ex.get_top_20_comp())
			{
				cout << "You have hier 3 terts: ";
				count_you = 60;
				show_words(x, y, turn, Ex);
				return 0;
			}
			else if (Ex.get_top_20_you() < Ex.get_top_20_comp())
			{
				cout << "Comp has  hier 3 terts: ";
				count_comp = 60;
				return pre_words_helper(x, y, turn, Ex);
			}
			else if (Ex.get_top_20_you() == Ex.get_top_20_comp())
			{
				if (!turn)
				{
					cout << "VashIb 3 terts po krygy first: ";
					count_you = 60;
					show_words(x, y, turn, Ex);
					return 0;
				}
				else
				{
					cout << "Sorry comp's 3 terts are first po krygy: ";
					count_comp = 60;
					show_words(x, y, turn, Ex);
					return 0;
				}
			}
		}
		if (x == 4)
		{
			if (Ex.get_top_50_you() > Ex.get_top_50_comp())
			{
				cout << "You have a hier paltos: ";
				count_you = 50;
				show_words(x, y, turn, Ex);
				return 0;
			}
			else if (Ex.get_top_50_you() < Ex.get_top_50_comp())
			{
				cout << "Comp has a hier paltos: ";
				count_comp = 50;
				return pre_words_helper(x, y, turn, Ex);
			}
			else if (Ex.get_top_50_you() == Ex.get_top_50_comp())
			{
				if (!turn)
				{
					cout << "Vash paltos po krygy first: ";
					count_you = 50;
					show_words(x, y, turn, Ex);
					return 0;
				}
				else
				{
					cout << "Sorry comp's paltos is first po krygy: ";
					count_comp = 50;
					show_words(x, y, turn, Ex);
					return 0;
				}
			}
		}
		if (x == 5)
		{
			if (Ex.get_top_50_you() > Ex.get_top_50_comp())
			{
				cout << "You have a hier paltos and terts: ";
				count_you = 70;
				show_words(x, y, turn, Ex);
				return 0;
			}
			else if (Ex.get_top_50_you() < Ex.get_top_50_comp())
			{
				cout << "Comp has a hier paltos and terts: ";
				count_comp = 70;
				return pre_words_helper(x, y, turn, Ex);
			}
			else if (Ex.get_top_50_you() == Ex.get_top_50_comp())
			{
				if (Ex.get_top_20_you() > Ex.get_top_20_comp())
				{
					cout << "You have a paltos and a hier terts: ";
					count_you = 70;
					show_words(x, y, turn, Ex);
					return 0;
				}
				if (Ex.get_top_20_you() < Ex.get_top_20_comp())
				{
					cout << "Comp has a paltos and a hier terts: ";
					count_comp = 70;
					return pre_words_helper(x, y, turn, Ex);
				}
				if (Ex.get_top_20_you() == Ex.get_top_20_comp())
				{
					if (!turn)
					{
						cout << "Vash paltos i terts po krygy first: ";
						count_you = 70;
						show_words(x, y, turn, Ex);
						return 0;
					}
					else
					{
						cout << "Sorry comp's paltos i terts are first po krygy: ";
						count_comp = 70;
						show_words(x, y, turn, Ex);
						return 0;
					}
				}
			}
		}
		if (x == 6)
		{
			if (Ex.get_top_50_you() > Ex.get_top_50_comp())
			{
				cout << "You have a hier paltos and 2 terts: ";
				count_you = 90;
				show_words(x, y, turn, Ex);
				return 0;
			}
			else if (Ex.get_top_50_you() < Ex.get_top_50_comp())
			{
				cout << "Comp has a hier paltos and 2 terts: ";
				count_comp = 90;
				return pre_words_helper(x, y, turn, Ex);
			}
			else if (Ex.get_top_50_you() == Ex.get_top_50_comp())
			{
				if (Ex.get_top_20_you() > Ex.get_top_20_comp())
				{
					cout << "You have a paltos and a hier 2 terts: ";
					count_you = 90;
					show_words(x, y, turn, Ex);
					return 0;
				}
				if (Ex.get_top_20_you() < Ex.get_top_20_comp())
				{
					cout << "Comp has a paltos and a hier 2 terts: ";
					count_comp = 90;
					return pre_words_helper(x, y, turn, Ex);
				}
				if (Ex.get_top_20_you() == Ex.get_top_20_comp())
				{
					if (!turn)
					{
						cout << "Vash paltos i 2 terts po krygy first: ";
						count_you = 90;
						show_words(x, y, turn, Ex);
						return 0;
					}
				}
				else
				{
					cout << "Sorry comp's paltos i 2 terts are first po krygy: ";
					count_comp = 90;
					show_words(x, y, turn, Ex);
					return 0;
				}
			}
		}
	}
	if (x == 8)
	{
		if (Ex.get_top_50_you() > Ex.get_top_50_comp())
		{
			cout << "You have hier paltosbI: ";
			count_you = 100;
			show_words(x, y, turn, Ex);
			return 0;
		}
		else if (Ex.get_top_50_you() < Ex.get_top_50_comp())
		{
			cout << "Comp has hier paltosbI: ";
			count_comp = 100;
			return pre_words_helper(x, y, turn, Ex);
		}
		else if (Ex.get_top_50_you() == Ex.get_top_50_comp())
		{
			if (!turn)
			{
				cout << "Vashi paltosbI po krygy first: ";
				count_you = 100;
				show_words(x, y, turn, Ex);
				return 0;
			}
			else
			{
				cout << "Sorry comp's paltosbI are first po krygy: ";
				count_comp = 100;
				return pre_words_helper(x, y, turn, Ex);
			}
		}
	}
	else if (x > y)
	{
		if (x == 4 && y == 3)
		{
			cout << "Comp has 3 terts.";
			count_comp = 60;
			return pre_words_helper(x, y, turn, Ex);
		}
		else
		{
			switch (x)
			{
			case 1:
				cout << "You have a terts ";
				count_you = 20;
				show_words(x, y, turn, Ex);
				return 0;
			case 2:
				cout << "You have 2 terts ";
				count_you = 40;
				show_words(x, y, turn, Ex);
				return 0;
			case 3:
				cout << "You have 3 terts ";
				count_you = 60;
				show_words(x, y, turn, Ex);
				return 0;
			case 4:
				cout << "You have a paltos ";
				count_you = 50;
				show_words(x, y, turn, Ex);
				return 0;
			case 5:
				cout << "You have paltos and terts ";
				count_you = 70;
				show_words(x, y, turn, Ex);
				return 0;
			case 6:
				cout << "You have paltos and 2 terts ";
				count_you = 90;
				show_words(x, y, turn, Ex);
				return 0;
			case 8:
				cout << "You have 2 paltosa ";
				count_you = 100;
				show_words(x, y, turn, Ex);
				return 0;
			}
		}
	}
	else if (x < y)
	{
		if (x == 3 && y == 4)
		{
			cout << "You have 3 terts ";
			count_you = 60;
			show_words(x, y, turn, Ex);
			return 0;
		}
		else
		{
			switch (y)
			{
			case 1:
				cout << "Comp has terts ";
				count_comp = 20;
				return pre_words_helper(x, y, turn, Ex);
			case 2:
				cout << "Comp has 2 terts ";
				count_comp = 40;
				return pre_words_helper(x, y, turn, Ex);
			case 3:
				cout << "Comp has 3 terts ";
				count_comp = 60;
				return pre_words_helper(x, y, turn, Ex);
			case 4:
				cout << "Comp has paltos ";
				count_comp = 50;
				return pre_words_helper(x, y, turn, Ex);
			case 5:
				cout << "Comp has paltos and terts ";
				count_comp = 70;
				return pre_words_helper(x, y, turn, Ex);
			case 6:
				cout << "Comp has paltos and 2 terts ";
				count_comp = 90;
				return pre_words_helper(x, y, turn, Ex);
			case 8:
				cout << "Comp has 2 paltosa";
				count_comp = 100;
				return pre_words_helper(x, y, turn, Ex);
			}
		}

	}

}
string& your_move_you_helper1(string&x)
{
	regex a("1|2");
	while (1)
	{
		getline(cin, x);
		if (!regex_match(x,a))
			continue;
		else
			return x;
	}
}
string& your_move_you_helper2(string&x)
{
	regex a("1|2|3");
	while (1)
	{
		getline(cin, x);
		if (!regex_match(x, a))
			continue;
		else
			return x;
	}
}
string& your_move_you_helper3(string&x)
{
	regex a("1|2|3|4");
	while (1)
	{
		getline(cin, x);
		if (!regex_match(x, a))
			continue;
		else
			return x;
	}
}
string& your_move_you_helper4(string&x)
{
	regex a("1|2|3|4|5");
	while (1)
	{
		getline(cin, x);
		if (!regex_match(x, a))
			continue;
		else
			return x;
	}
}
string& your_move_you_helper5(string&x)
{
	regex a("1|2|3|4|5|6");
	while (1)
	{
		getline(cin, x);
		if (!regex_match(x, a))
			continue;
		else
			return x;
	}
}
string& your_move_you_helper6(string&x)
{
	regex a("1|2|3|4|5|6|7");
	while (1)
	{
		getline(cin, x);
		if (!regex_match(x, a))
			continue;
		else
			return x;
	}
}
string& your_move_you_helper7(string&x)
{
	regex a("1|2|3|4|5|6|7|8");
	while (1)
	{
		getline(cin, x);
		if (!regex_match(x, a))
			continue;
		else
			return x;
	}
}
string& your_move_you_helper8(string&x)
{
	regex a("1|2|3|4|5|6|7|8|9");
	while (1)
	{
		getline(cin, x);
		if (!regex_match(x, a))
			continue;
		else
			return x;
	}
}
string& your_move_you_helper9(string&x)
{
	regex a("1|2|3|4|5|6|7|8|9|10");
	while (1)
	{
		getline(cin, x);
		if (!regex_match(x, a))
			continue;
		else
			return x;
	}
}
void split_suits_comp_move_helper(Game&Ex, bool a, bool b, bool c, bool d)
{
	vector<Card>::iterator it = Ex.get_hand_comp().begin();
	while (it != Ex.get_hand_comp().end() && (*it).get_suit() == 3)
		Ex.get_hearts_comp_move().push_back(pair<char, int>(3, helper2((*it++).get_value().data()[0], a)));
	while (it != Ex.get_hand_comp().end() && (*it).get_suit() == 4)
		Ex.get_diamonds_comp_move().push_back(pair<char, int>(4, helper2((*it++).get_value().data()[0], b)));
	while (it != Ex.get_hand_comp().end() && (*it).get_suit() == 5)
		Ex.get_clubs_comp_move().push_back(pair<char, int>(5, helper2((*it++).get_value().data()[0], c)));
	while (it != Ex.get_hand_comp().end() && (*it).get_suit() == 6)
		Ex.get_speads_comp_move().push_back(pair<char, int>(6, helper2((*it++).get_value().data()[0], d)));

}
void split_suits_comp_move(Game&Ex)
{
	
	switch (kozir_fin)
	{
	case 3:
		split_suits_comp_move_helper(Ex, 1, 0, 0, 0);
	break;
	case 4:
		split_suits_comp_move_helper(Ex, 0, 1, 0, 0);
	break;
	case 5:
		split_suits_comp_move_helper(Ex, 0, 0, 1, 0);
	break;
	case 6:
		split_suits_comp_move_helper(Ex, 0, 0, 0, 1);
	}
}
void split_suits_comp_move_dop_helper(Game&Ex, bool a, bool b, bool c, bool d)
{
	vector<Card>::iterator it = Ex.get_hand_comp().begin();
	while (it != Ex.get_hand_comp().end() && (*it).get_suit() == 3)
		Ex.get_hearts_comp_dop().push_back(pair<char, int>(3, helper2((*it++).get_value().data()[0], a)));
	while (it != Ex.get_hand_comp().end() && (*it).get_suit() == 4)
		Ex.get_diamonds_comp_dop().push_back(pair<char, int>(4, helper2((*it++).get_value().data()[0], b)));
	while (it != Ex.get_hand_comp().end() && (*it).get_suit() == 5)
		Ex.get_clubs_comp_dop().push_back(pair<char, int>(5, helper2((*it++).get_value().data()[0], c)));
	while (it != Ex.get_hand_comp().end() && (*it).get_suit() == 6)
		Ex.get_speads_comp_dop().push_back(pair<char, int>(6, helper2((*it++).get_value().data()[0], d)));

}
void split_suits_comp_move_dop(Game&Ex)
{
	
	switch (kozir_fin)
	{
	case 3:
		split_suits_comp_move_dop_helper(Ex, 1, 0, 0, 0);
	break;
	case 4:
		split_suits_comp_move_dop_helper(Ex, 0, 1, 0, 0);
	break;
	case 5:
		split_suits_comp_move_dop_helper(Ex, 0, 0, 1, 0);
	break;
	case 6:
		split_suits_comp_move_dop_helper(Ex, 0, 0, 0, 1);
	}
}
bool predicat_move1(pair<char, int>&Ex)
{
	return Ex.second > card_your_move_val;
}
bool predicat_move2(Card&Ex)
{
	return (Ex.get_suit() == card_comp_move.first)&&(Ex.get_value() == card_comp_move.second);
}
bool predicat_move2_you(Card&Ex)
{
	return (Ex.get_suit() == card_your_move.first) && (Ex.get_value() == card_your_move.second);
}
bool predicat_move3(Card&Ex)
{
	return Ex.get_suit() == kozir_fin;
}
string& convert(int x,vector<pair<char,int>>&Ex)
{
	if (Ex[0].first != kozir_fin)
	{
		switch (x)
		{
		case 1:
			A = "7";
			break;
		case 2:
			A = "8";
			break;
		case 3:
			A = "9";
			break;
		case 4:
			A = "J";
			break;
		case 5:
			A = "Q";
			break;
		case 6:
			A = "K";
			break;
		case 7:
			A = "10";
			break;
		case 8:
			A = "A";
		}
	}
	else
	{
		switch (x)
		{
		case 1:
			A = "7";
			break;
		case 2:
			A = "8";
			break;
		case 3:
			A = "Q";
			break;
		case 4:
			A = "K";
			break;
		case 5:
			A = "10";
			break;
		case 6:
			A = "A";
			break;
		case 7:
			A = "9";
			break;
		case 8:
			A = "J";
		}
	}
	return A;
}
void erase_suits_move(vector<pair<char, int>>&Ex, vector<pair<char, int>>&Ex1, vector<pair<char, int>>&Ex2, vector<pair<char, int>>&Ex3)
{
	if (Ex.size())
		Ex.erase(Ex.begin(), Ex.end());
	if (Ex1.size())
		Ex1.erase(Ex1.begin(), Ex1.end());
	if (Ex2.size())
		Ex2.erase(Ex2.begin(), Ex2.end());
	if (Ex3.size())
		Ex3.erase(Ex3.begin(), Ex3.end());
}
bool compare01(pair<char, int>&Ex, pair<char, int>&Ex2)
{
	return Ex.second < Ex2.second;
}
void set_card_move_erase(int mastb, string Ex_a,Game&Ex)
{
	vector<Card>::iterator it;
	card_comp_move.first = mastb;
	card_comp_move.second = Ex_a;
	Ex.get_card_comp_move().set_suit_value(mastb,Ex_a);
	it = find_if(Ex.get_hand_comp().begin(), Ex.get_hand_comp().end(), predicat_move2);
	Ex.get_hand_comp().erase(it);
	erase_suits_move(Ex.get_hearts_comp_move(), Ex.get_diamonds_comp_move(), Ex.get_clubs_comp_move(), Ex.get_speads_comp_move());
}
void choose_smaller(int a, int b, int c, Game&Ex,vector<pair<char,int>>&a1,vector<pair<char,int>>&a2,vector<pair<char,int>>&a3)
{
	
	if (a > b&&a > c)
		set_card_move_erase(a1[0].first,convert(a1[0].second,a1), Ex);
	else if (b > a&&b > c)
		set_card_move_erase(a2[0].first, convert(a2[0].second,a2), Ex);
	else if (c > a&&c > b)
		set_card_move_erase(a3[0].first, convert(a3[0].second,a3), Ex);
	else if (a > c&&a == b)
	{
		if (a1[0].second<a2[0].second)
			set_card_move_erase(a1[0].first, convert(a1[0].second,a1), Ex);
		else
			set_card_move_erase(a2[0].first,convert(a2[0].second,a2), Ex);
	}
	else if (b > a&&b == c)
	{
		if (a2[0].second<a3[0].second)
			set_card_move_erase(a2[0].first,convert(a2[0].second,a2), Ex);
		else
			set_card_move_erase(a3[0].first,convert(a3[0].second,a3), Ex);
	}
	else if (c > b&&c == a)
	{
		if (a3[0].second < a1[0].second)
			set_card_move_erase(a3[0].first, convert(a3[0].second,a3), Ex);
		else
			set_card_move_erase(a1[0].first, convert(a1[0].second,a1), Ex);
	}
	else if (a == b || a == c)
	{
		if (a1[0].second<a2[0].second&&a1[0].second<a3[0].second)
			set_card_move_erase(a1[0].first, convert(a1[0].second,a1), Ex);
		else if (a2[0].second < a1[0].second&&a2[0].second < a3[0].second)
			set_card_move_erase(a2[0].first, convert(a2[0].second,a2), Ex);
		else if (a3[0].second < a1[0].second&&a3[0].second < a2[0].second)
			set_card_move_erase(a3[0].first, convert(a3[0].second,a3), Ex);
		else if (a1[0].second < a3[0].second&&a1[0].second == a2[0].second)
			set_card_move_erase(a1[0].first, convert(a1[0].second,a1), Ex);
		else if (a2[0].second < a1[0].second&&a2[0].second == a3[0].second)
			set_card_move_erase(a2[0].first, convert(a2[0].second,a2), Ex);
		else if (a3[0].second < a2[0].second&&a3[0].second == a1[0].second)
			set_card_move_erase(a3[0].first, convert(a3[0].second,a3), Ex);
		else if (a1[0].second == a2[0].second && a1[0].second == a3[0].second)
			set_card_move_erase(a1[0].first, convert(a1[0].second,a1), Ex);
	}
}
bool comp_move_after_you_helper_not_kozir_fin(int size_hearts, int size_diamonds, int size_clubs, int size_speads, Game& Ex,
	vector<pair<char, int>>&greater, vector<Card>&koziri, vector<pair<char, int>>&suit,int first_size)
{
	bool x1=0;
	if (suit.size())
	{
		vector<pair<char, int>>::iterator it = find_if(suit.begin(), suit.end(), predicat_move1);
		while (it != suit.end())
		{
			greater.push_back((*it++));
			x1 = 1;
		}
		if (x1)
		{
			if (first_size < 5)
				set_card_move_erase(greater[0].first, convert(greater[0].second,greater), Ex);
			else
				set_card_move_erase((*(greater.end() - 1)).first, convert((*(greater.end() - 1)).second,greater), Ex);
			return 1;
		}
		else
		{
			set_card_move_erase(suit[0].first, convert(suit[0].second,suit), Ex);
			return 0;
		}
	}
	else
	{
		bool x1 = 0;
		vector<Card>::iterator it = find_if(Ex.get_hand_comp().begin(), Ex.get_hand_comp().end(), predicat_move3);
		while (it != Ex.get_hand_comp().end())
		{
			x1 = 1;
			koziri.push_back((*it));
			if (++it == Ex.get_hand_comp().end())
				break;
			it = find_if(it, Ex.get_hand_comp().end(), predicat_move3);
		}
		if (x1)
		{
			if (priority_comp == 0 || priority_comp == 1 || priority_comp == 4)
			{
				string a = "9";
				card_comp_move.first = kozir_fin;
				card_comp_move.second = "9";
				vector<Card>::iterator it = find_if(Ex.get_hand_comp().begin(), Ex.get_hand_comp().end(), predicat_move2);
				if (it != Ex.get_hand_comp().end())
				{
					Ex.get_card_comp_move().set_suit_value(kozir_fin, a);
					Ex.get_hand_comp().erase(it);
					erase_suits_move(Ex.get_hearts_comp_move(), Ex.get_diamonds_comp_move(), Ex.get_clubs_comp_move(), Ex.get_speads_comp_move());
				}
				else
				{
					set_card_move_erase(kozir_fin, (*(koziri.end() - 1)).get_value(), Ex);
					
				}
			}
			else if (priority_comp == 3 || priority_comp == 2 || (priority_comp > 4))
			{	
				set_card_move_erase(kozir_fin,koziri[0].get_value(), Ex);
				
			}
			return 1;
		}
		else
		{
			switch (kozir_fin)
			{
			case 3:
				choose_smaller(size_diamonds, size_clubs, size_speads, Ex, Ex.get_diamonds_comp_move(), Ex.get_clubs_comp_move(), Ex.get_speads_comp_move());
				return 0;
			case 4:
				choose_smaller(size_hearts, size_clubs, size_speads, Ex, Ex.get_hearts_comp_move(), Ex.get_clubs_comp_move(), Ex.get_speads_comp_move());
				return 0;
			case 5:
				choose_smaller(size_hearts, size_diamonds, size_speads, Ex, Ex.get_hearts_comp_move(), Ex.get_diamonds_comp_move(), Ex.get_speads_comp_move());
				return 0;
			case 6:
				choose_smaller(size_hearts, size_diamonds, size_clubs, Ex, Ex.get_hearts_comp_move(), Ex.get_diamonds_comp_move(), Ex.get_clubs_comp_move());
				return 0;
			}
		}

	}
}
bool comp_after_you_helper_kozir_fin(vector<pair<char, int>>&suit, vector<pair<char, int>>&greater, Game&Ex,int size_hearts,int size_diamonds,int size_clubs,int size_speads)
{
	bool x1 = 0;
	if (suit.size())
	{
		vector<pair<char, int>>::iterator it = find_if(suit.begin(), suit.end(), predicat_move1);
		while (it != suit.end())
		{
			greater.push_back((*it++));
			x1 = 1;
		}
		if (x1)
		{
			if (priority_comp == 0 || priority_comp == 1 || priority_comp == 4)
			{
				set_card_move_erase(kozir_fin, convert((*(greater.end() - 1)).second,greater), Ex);
				
			}
			else if (priority_comp == 3 || priority_comp == 2 || (priority_comp > 4))
			{
				set_card_move_erase(kozir_fin, convert(greater[0].second,greater), Ex);
				
			}
			return 1;
		}
		else
		{
			set_card_move_erase(kozir_fin, convert(suit[0].second,suit), Ex);
			
			return 0;
		}
	}
	else
	{
		switch (kozir_fin)
		{
		case 3:
			choose_smaller(size_diamonds, size_clubs, size_speads, Ex, Ex.get_diamonds_comp_move(), Ex.get_clubs_comp_move(), Ex.get_speads_comp_move());
			return 0;
		case 4:
			choose_smaller(size_hearts, size_clubs, size_speads, Ex, Ex.get_hearts_comp_move(), Ex.get_clubs_comp_move(), Ex.get_speads_comp_move());
			return 0;
		case 5:
			choose_smaller(size_hearts, size_diamonds, size_speads, Ex, Ex.get_hearts_comp_move(), Ex.get_diamonds_comp_move(), Ex.get_speads_comp_move());
			return 0;
		case 6:
			choose_smaller(size_hearts, size_diamonds, size_clubs, Ex, Ex.get_hearts_comp_move(), Ex.get_diamonds_comp_move(), Ex.get_clubs_comp_move());
			return 0;
		}
	}
}
bool comp_move_after_you(Game&Ex)
{
		split_suits_comp_move(Ex);
		sort(Ex.get_hearts_comp_move().begin(), Ex.get_hearts_comp_move().end(), compare0);
		sort(Ex.get_diamonds_comp_move().begin(), Ex.get_diamonds_comp_move().end(), compare0);
		sort(Ex.get_clubs_comp_move().begin(), Ex.get_clubs_comp_move().end(), compare0);
		sort(Ex.get_speads_comp_move().begin(), Ex.get_speads_comp_move().end(), compare0);
		if (Ex.get_card_your_move().get_suit() != kozir_fin)
			card_your_move_val = helper2(Ex.get_card_your_move().get_value().data()[0], 0);
		else
			card_your_move_val = helper2(Ex.get_card_your_move().get_value().data()[0], 1);
		int size_hearts = Ex.get_hearts_comp_move().size();
		int size_diamonds = Ex.get_diamonds_comp_move().size();
		int size_clubs = Ex.get_clubs_comp_move().size();
		int size_speads = Ex.get_speads_comp_move().size();
		vector<pair<char, int>>greater;
		vector<Card>koziri;
		bool x1 = 0;
		if (Ex.get_card_your_move().get_suit() != kozir_fin)
		{
			switch (Ex.get_card_your_move().get_suit())
			{
			case 3:
				return comp_move_after_you_helper_not_kozir_fin(size_hearts, size_diamonds, size_clubs, size_speads, Ex, greater, koziri, Ex.get_hearts_comp_move(),size_hearts_comp);
			case 4:
				return comp_move_after_you_helper_not_kozir_fin(size_hearts, size_diamonds, size_clubs, size_speads, Ex, greater, koziri, Ex.get_diamonds_comp_move(),size_diamonds_comp);
			case 5:
				return comp_move_after_you_helper_not_kozir_fin(size_hearts, size_diamonds, size_clubs, size_speads, Ex, greater, koziri, Ex.get_clubs_comp_move(),size_clubs_comp);
			case 6:
				return comp_move_after_you_helper_not_kozir_fin(size_hearts, size_diamonds, size_clubs, size_speads, Ex, greater, koziri, Ex.get_speads_comp_move(),size_speads_comp);
			}
		}
		else
		{
			switch (kozir_fin)
			{
			case 3:
				return  comp_after_you_helper_kozir_fin(Ex.get_hearts_comp_move(), greater ,Ex,size_hearts, size_diamonds, size_clubs, size_speads);
			case 4:
				return  comp_after_you_helper_kozir_fin(Ex.get_diamonds_comp_move(), greater, Ex,size_hearts, size_diamonds, size_clubs, size_speads);
			case 5:
				return  comp_after_you_helper_kozir_fin(Ex.get_clubs_comp_move(), greater, Ex, size_hearts, size_diamonds, size_clubs, size_speads);
			case 6:
				return  comp_after_you_helper_kozir_fin(Ex.get_speads_comp_move(), greater, Ex, size_hearts, size_diamonds, size_clubs, size_speads);
			}
		}
}
bool your_move_you_helper_all(int x, Game&Ex)
{
	cout << "You: " << Ex.get_hand_you()[x].get_suit() << " " << Ex.get_hand_you()[x].get_value();
	Ex.get_card_your_move().set_suit_value(Ex.get_hand_you()[x].get_suit(), Ex.get_hand_you()[x].get_value());
	Ex.get_hand_you().erase(Ex.get_hand_you().begin() + x);
	return comp_move_after_you(Ex);
}
bool your_move_you_helper_all_show_words(int x, Game&Ex,int a,int b,bool c)
{
	if (words_comp)
	{
		show_words(a, b, c, Ex);
	}
	cout << "You: " << Ex.get_hand_you()[x].get_suit() << " " << Ex.get_hand_you()[x].get_value();
	Ex.get_card_your_move().set_suit_value(Ex.get_hand_you()[x].get_suit(), Ex.get_hand_you()[x].get_value());
	Ex.get_hand_you().erase(Ex.get_hand_you().begin() + x);
	return comp_move_after_you(Ex);
}
bool your_move_you(Game&Ex,int a,int b,bool c)
{
	int x = Ex.get_hand_you().size();
	int y = 1;
	string z;
	cout << "Your move:" << endl;
	for (; y <= x; y++)
		cout << y << Ex.get_hand_you()[y - 1].get_suit() << " " << Ex.get_hand_you()[y - 1].get_value()<<endl;
	cout << "Kozir " << kozir_fin << endl;
	switch (x)
	{
	case 1:
		return your_move_you_helper_all(0, Ex);
	case 2:
		z = your_move_you_helper1(z);
		switch (z[0])
		{
		case '1':
			return your_move_you_helper_all(0, Ex);
		case '2':
			return your_move_you_helper_all(1, Ex);
		}
	case 3:
		z = your_move_you_helper2(z);
		switch (z[0])
		{
		case '1':
			return your_move_you_helper_all(0, Ex);
		case '2':
			return your_move_you_helper_all(1, Ex);
		case '3':
			return your_move_you_helper_all(2, Ex);
		}
	case 4:
		z = your_move_you_helper3(z);
		switch (z[0])
		{
		case '1':
			return your_move_you_helper_all(0, Ex);
		case '2':
			return your_move_you_helper_all(1, Ex);
		case '3':
			return your_move_you_helper_all(2, Ex);
		case '4':
			return your_move_you_helper_all(3, Ex);
		}
	case 5:
		z = your_move_you_helper4(z);
		switch (z[0])
		{
		case '1':
			return your_move_you_helper_all(0, Ex);
		case '2':
			return your_move_you_helper_all(1, Ex);
		case '3':
			return your_move_you_helper_all(2, Ex);
		case '4':
			return your_move_you_helper_all(3, Ex);
		case '5':
			return your_move_you_helper_all(4, Ex);
		}
	case 6:
		z = your_move_you_helper5(z);
		switch (z[0])
		{
		case '1':
			return your_move_you_helper_all(0, Ex);
		case '2':
			return your_move_you_helper_all(1, Ex);
		case '3':
			return your_move_you_helper_all(2, Ex);
		case '4':
			return your_move_you_helper_all(3, Ex);
		case '5':
			return your_move_you_helper_all(4, Ex);
		case '6':
			return your_move_you_helper_all(5, Ex);
		}
	case 7:
		z = your_move_you_helper6(z);
		switch (z[0])
		{
		case '1':
			return your_move_you_helper_all(0, Ex);
		case '2':
			return your_move_you_helper_all(1, Ex);
		case '3':
			return your_move_you_helper_all(2, Ex);
		case '4':
			return your_move_you_helper_all(3, Ex);
		case '5':
			return your_move_you_helper_all(4, Ex);
		case '6':
			return your_move_you_helper_all(5, Ex);
		case '7':
			return your_move_you_helper_all(6, Ex);
		}
	case 8:
		z = your_move_you_helper7(z);
		switch (z[0])
		{
		case '1':
			return your_move_you_helper_all(0, Ex);
		case '2':
			return your_move_you_helper_all(1, Ex);
		case '3':
			return your_move_you_helper_all(2, Ex);
		case '4':
			return your_move_you_helper_all(3, Ex);
		case '5':
			return your_move_you_helper_all(4, Ex);
		case '6':
			return your_move_you_helper_all(5, Ex);
		case '7':
			return your_move_you_helper_all(6, Ex);
		case '8':
			return your_move_you_helper_all(7, Ex);
		}
	case 9:
		z = your_move_you_helper8(z);
		switch (z[0])
		{
		case '1':
			return your_move_you_helper_all(0, Ex);
		case '2':
			return your_move_you_helper_all(1, Ex);
		case '3':
			return your_move_you_helper_all(2, Ex);
		case '4':
			return your_move_you_helper_all(3, Ex);
		case '5':
			return your_move_you_helper_all(4, Ex);
		case '6':
			return your_move_you_helper_all(5, Ex);
		case '7':
			return your_move_you_helper_all(6, Ex);
		case '8':
			return your_move_you_helper_all(7, Ex);
		case '9':
			return your_move_you_helper_all(8, Ex);
		}
	case 10:
		z = your_move_you_helper9(z);
		switch (z[0])
		{
		case '1':
			if (z[1] == '0')
				return your_move_you_helper_all_show_words(9, Ex, a, b, c);
			else
			return your_move_you_helper_all_show_words(0, Ex,a,b,c);
		case '2':
			return your_move_you_helper_all_show_words(1, Ex, a, b, c);
		case '3':
			return your_move_you_helper_all_show_words(2, Ex, a, b, c);
		case '4':
			return your_move_you_helper_all_show_words(3, Ex, a, b, c);
		case '5':
			return your_move_you_helper_all_show_words(4, Ex, a, b, c);
		case '6':
			return your_move_you_helper_all_show_words(5, Ex, a, b, c);
		case '7':
			return your_move_you_helper_all_show_words(6, Ex, a, b, c);
		case '8':
			return your_move_you_helper_all_show_words(7, Ex, a, b, c);
		case '9':
			return your_move_you_helper_all_show_words(8, Ex, a, b, c);
		}
	}
}
bool predicat_A(pair<char,int>&Ex)
{
	return Ex.second == 8;
}
void comp_move_helper2(vector<pair<char, int>>&Ex1,Game&Ex)
{
	if (find_if(Ex1.begin(), Ex1.end(), predicat_A) != Ex1.end())
	{
		card_comp_move.first = Ex1[0].first;
		card_comp_move.second = "A";
		set_card_move_erase(card_comp_move.first, card_comp_move.second, Ex);
	}
	else
	{
		card_comp_move.first = Ex1[0].first;
		card_comp_move.second = convert(Ex1[0].second, Ex1);
		set_card_move_erase(card_comp_move.first, card_comp_move.second, Ex);
	}
}
bool comp_move_helper1(int size_glob1, int size_glob2, int size_glob3,int a,int b,int c, vector<pair<char, int>>&Ex1, vector<pair<char, int>>&Ex2, vector<pair<char, int>>&Ex3,Game&Ex)
{
	if (size_glob1 >= 4)
	{
		if (a)
		{
			comp_move_helper2(Ex1,Ex);
			return 1;
		}
		else
			return 0;
	}
	else if (size_glob2 >= 4)
	{
		if (b)
		{
			comp_move_helper2(Ex2,Ex);
			return 1;
		}
		else
			return 0;
	}
	else if (size_glob3 >= 4)
	{
		if (c)
		{
			comp_move_helper2(Ex3, Ex);
			return 1;
		}
		else
			return 0;
	}
	else
		return 0;
}
bool comp_move_helper3(int a, int b, int c, vector<pair<char, int>>&Ex1,vector<pair<char,int>>&Ex2,vector<pair<char,int>>&Ex3,Game&Ex)
{
	if (a == 0 && b == 0 && c == 0)
		return 0;
	else
	{
		choose_smaller(a, b, c, Ex, Ex1, Ex2, Ex3);
		return 1;
	}
}
bool comp_move_helper4(int suit_size, int suit,Game&Ex)
{
	if (priority_comp == 3 && suit_size >= 3)
	{
		card_comp_move.first = suit;
		card_comp_move.second = "J";
		if (find_if(Ex.get_hand_comp().begin(), Ex.get_hand_comp().end(), predicat_move2) != Ex.get_hand_comp().end())
		{
			set_card_move_erase(suit, card_comp_move.second, Ex);
			return 1;
		}
		else
			return 0;
	}
	else if (priority_comp >= 4)
	{
		card_comp_move.first = suit;
		card_comp_move.second = "J";
		if (find_if(Ex.get_hand_comp().begin(), Ex.get_hand_comp().end(), predicat_move2) != Ex.get_hand_comp().end())
		{
			set_card_move_erase(suit, card_comp_move.second, Ex);
			return 1;
		}
		else
		{
			card_comp_move.first = suit;
			card_comp_move.second = "9";
			if (find_if(Ex.get_hand_comp().begin(), Ex.get_hand_comp().end(), predicat_move2) != Ex.get_hand_comp().end())
			{
				set_card_move_erase(suit, card_comp_move.second, Ex);
				return 1;
			}
			else
			{
				card_comp_move.first = suit;
				card_comp_move.second = "A";
				if (find_if(Ex.get_hand_comp().begin(), Ex.get_hand_comp().end(), predicat_move2) != Ex.get_hand_comp().end())
				{
					set_card_move_erase(suit, card_comp_move.second, Ex);
					return 1;
				}
				else
					return 0;
			}
		}
	}
	else
		return 0;
}
bool comp_move_helper5(vector<pair<char, int>>&Ex1,Game&Ex)
{
	if (Ex1.size())
	{
		card_comp_move.first = Ex1[0].first;
		card_comp_move.second = convert(Ex1[0].second, Ex1);
		set_card_move_erase(card_comp_move.first, card_comp_move.second, Ex);
		return 1;
	}
	else
		return 0;
}
bool comp_move_helper6(int v_kozir,vector<pair<char, int>>&Ex1, vector<pair<char, int>>&Ex2, vector<pair<char, int>>&Ex3, vector<pair<char, int>>&Ex4, Game&Ex)
{
	switch (v_kozir)
	{
	case 3:
		return comp_move_helper5(Ex1, Ex);
	case 4:
		return comp_move_helper5(Ex2, Ex);
	case 5:
		return comp_move_helper5(Ex3, Ex);
	case 6:
		return comp_move_helper5(Ex4, Ex);
	}
}
void comp_move_helper7(int suit, vector<pair<char, int>>&Ex1,Game&Ex)
{
	card_comp_move.first = suit;
	card_comp_move.second = convert(Ex1[0].second, Ex1);
	set_card_move_erase(card_comp_move.first, card_comp_move.second, Ex);
}
void comp_move_comp(Game&Ex)
{
	
	int size_hearts_dop = 0;
	int size_diamonds_dop = 0;
	int size_clubs_dop = 0;
	int size_speads_dop = 0;
	int x = 1;
	for (; x <= Ex.get_hand_you().size(); x++)
		cout << x << Ex.get_hand_you()[x - 1].get_suit() << Ex.get_hand_you()[x - 1].get_value() << endl;
	split_suits_comp_move(Ex);
	sort(Ex.get_hearts_comp_move().begin(), Ex.get_hearts_comp_move().end(), compare0);
	sort(Ex.get_diamonds_comp_move().begin(), Ex.get_diamonds_comp_move().end(), compare0);
	sort(Ex.get_clubs_comp_move().begin(), Ex.get_clubs_comp_move().end(), compare0);
	sort(Ex.get_speads_comp_move().begin(), Ex.get_speads_comp_move().end(), compare0);
    size_hearts_dop=Ex.get_hearts_comp_move().size();
	size_diamonds_dop = Ex.get_diamonds_comp_move().size();
    size_clubs_dop = Ex.get_clubs_comp_move().size();
    size_speads_dop = Ex.get_speads_comp_move().size();
	switch (kozir_fin)
	{
	case 3:
		if (comp_move_helper4(size_hearts_comp, 3, Ex))
			return;
		else
    		break;
	case 4:
		if (comp_move_helper4(size_diamonds_comp, 4, Ex))
			return;
		else
		  break;
	case 5:
		if (comp_move_helper4(size_clubs_comp, 5, Ex))
			return;
		else
    		break;
	case 6:
		if (comp_move_helper4(size_speads_comp, 6, Ex))
			return;

	}
		if (v_kozir1 != 0)
			if (comp_move_helper6(v_kozir1, Ex.get_hearts_comp_move(), Ex.get_diamonds_comp_move(), Ex.get_clubs_comp_move(), Ex.get_speads_comp_move(), Ex))
				return;
		if (v_kozir2 != 0)
			if (comp_move_helper6(v_kozir2, Ex.get_hearts_comp_move(), Ex.get_diamonds_comp_move(), Ex.get_clubs_comp_move(), Ex.get_speads_comp_move(), Ex))
				return;
		if (v_kozir3 != 0)
			if (comp_move_helper6(v_kozir3, Ex.get_hearts_comp_move(), Ex.get_diamonds_comp_move(), Ex.get_clubs_comp_move(), Ex.get_speads_comp_move(), Ex))
				return;
		switch (kozir_fin)
		{
		case 3:
			if (comp_move_helper1(size_diamonds_comp, size_clubs_comp, size_speads_comp, size_diamonds_dop, size_clubs_dop, size_speads_dop, Ex.get_diamonds_comp_move(), Ex.get_clubs_comp_move(), Ex.get_speads_comp_move(),Ex))
				return;
			else
				break;
		case 4:
			if (comp_move_helper1(size_hearts_comp, size_clubs_comp, size_speads_comp, size_hearts_dop, size_clubs_dop, size_speads_dop, Ex.get_hearts_comp_move(), Ex.get_clubs_comp_move(), Ex.get_speads_comp_move(),Ex))
				return;
			else
				break;
		case 5:
			if (comp_move_helper1(size_hearts_comp, size_diamonds_comp, size_speads_comp, size_hearts_dop, size_diamonds_dop, size_speads_dop, Ex.get_hearts_comp_move(), Ex.get_diamonds_comp_move(), Ex.get_speads_comp_move(),Ex))
				return;
			else
				break;
		case 6:
			if (comp_move_helper1(size_hearts_comp, size_diamonds_comp, size_clubs_comp, size_hearts_dop, size_diamonds_dop, size_clubs_dop, Ex.get_hearts_comp_move(), Ex.get_diamonds_comp_move(), Ex.get_clubs_comp_move(),Ex))
				return;
		}
		switch (kozir_fin)
		{
		case 3:
			if (comp_move_helper3(size_diamonds_dop, size_clubs_dop, size_speads_dop, Ex.get_diamonds_comp_move(), Ex.get_clubs_comp_move(), Ex.get_speads_comp_move(), Ex))
			{
				
				return;
			}
			else
			{
				comp_move_helper7(3, Ex.get_hearts_comp_move(), Ex);
				return;
			}
		case 4:
			if (comp_move_helper3(size_hearts_dop, size_clubs_dop, size_speads_dop, Ex.get_hearts_comp_move(), Ex.get_clubs_comp_move(), Ex.get_speads_comp_move(), Ex))
			{
				
				return;
			}
			else
			{
				comp_move_helper7(4, Ex.get_diamonds_comp_move(), Ex);
				return;
			}
		case 5:
			if (comp_move_helper3(size_hearts_dop, size_diamonds_dop, size_speads_dop, Ex.get_hearts_comp_move(), Ex.get_diamonds_comp_move(), Ex.get_speads_comp_move(), Ex))
			{
				
				return;
			}
			else
			{
				comp_move_helper7(5, Ex.get_clubs_comp_move(), Ex);
				return;
			}
		case 6:
			if (comp_move_helper3(size_hearts_dop, size_diamonds_dop, size_clubs_dop, Ex.get_hearts_comp_move(), Ex.get_diamonds_comp_move(), Ex.get_clubs_comp_move(), Ex))
				return;
			else
			{
				comp_move_helper7(6, Ex.get_speads_comp_move(), Ex);
				return;
			}
		}
}
void split_suits_your_move_helper(int a,bool b1,bool b2,bool b3,bool b4,Game&Ex)
{
	vector<Card>::iterator it = Ex.get_hand_you().begin();
		while (it != Ex.get_hand_you().end() && (*it).get_suit() == a)
			Ex.get_hearts_you_move().push_back(pair<char, int>(a, helper2((*it++).get_value().data()[0], b1)));
		a++;
		while (it != Ex.get_hand_you().end() && (*it).get_suit() == a)
			Ex.get_diamonds_you_move().push_back(pair<char, int>(a, helper2((*it++).get_value().data()[0], b2)));
		a++;
		while (it != Ex.get_hand_you().end() && (*it).get_suit() == a)
			Ex.get_clubs_you_move().push_back(pair<char, int>(a, helper2((*it++).get_value().data()[0], b3)));
		a++;
		while (it != Ex.get_hand_you().end() && (*it).get_suit() == a)
			Ex.get_speads_you_move().push_back(pair<char, int>(a, helper2((*it++).get_value().data()[0], b4)));
}
void split_suits_your_move(Game&Ex)
{
	vector<Card>::iterator it = Ex.get_hand_you().begin();
	switch (kozir_fin)
	{
	case 3:
		split_suits_your_move_helper(3, 1, 0, 0, 0, Ex);
		break;
	case 4:
		split_suits_your_move_helper(3, 0, 1, 0, 0, Ex);
		break;
	case 5:
		split_suits_your_move_helper(3, 0, 0, 1, 0, Ex);
		break;
	case 6:
		split_suits_your_move_helper(3, 0, 0, 0, 1, Ex);
	}
}
void set_card_move_erase_you(int mastb, string Ex_a, Game&Ex)
{
	vector<Card>::iterator it;
	card_your_move.first = mastb;
	card_your_move.second = Ex_a;
	Ex.get_card_your_move().set_suit_value(mastb, Ex_a);
	it = find_if(Ex.get_hand_you().begin(), Ex.get_hand_you().end(), predicat_move2_you);
	Ex.get_hand_you().erase(it);
	erase_suits_move(Ex.get_hearts_you_move(), Ex.get_diamonds_you_move(), Ex.get_clubs_you_move(), Ex.get_speads_you_move());
}
bool check_greater_your_move(vector<pair<char,int>>&Ex1,Game&Ex)
{
	vector<pair<char, int>>::iterator it = Ex1.begin();
	for (; it != Ex1.end(); it++)
	{
		if ((*it).second > helper2(Ex.get_card_comp_move().get_value().data()[0], 1))
			return 1;
	}
	return 0;
}
int move_you_after_comp_helper(bool x1,int x, Game&Ex)
{
	card_your_move.first = Ex.get_hand_you()[x].get_suit();
	card_your_move.second = Ex.get_hand_you()[x].get_value();
	if (card_your_move.first == kozir_fin)
	{
		if (x1)
		{
			if (helper2(card_your_move.second.data()[0], 1) > helper2(card_comp_move.second.data()[0], 1))
			{
				set_card_move_erase_you(card_your_move.first, card_your_move.second, Ex);
				return 0;
			}
			else
				return 2;
		}
		else
		{
			set_card_move_erase_you(card_your_move.first, card_your_move.second, Ex);
			return 1;
		}
	}
	else
		return 3;
}
bool your_move_after_comp_choice21(Game&Ex, int x)
{
	card_your_move.first = Ex.get_hand_you()[x].get_suit();
	card_your_move.second = Ex.get_hand_you()[x].get_value();
	set_card_move_erase_you(card_your_move.first, card_your_move.second, Ex);
	if (helper2(card_your_move.second.data()[0], 0) > helper2(card_comp_move.second.data()[0], 0))
		return 0;
	else
		return 1;
}
bool your_move_after_comp_choice2(Game&Ex, int x)
{
	card_your_move.first = Ex.get_hand_you()[x].get_suit();
	card_your_move.second = Ex.get_hand_you()[x].get_value();
	set_card_move_erase_you(card_your_move.first, card_your_move.second, Ex);
	return 1;
}
bool your_move_after_comp_choice3(Game&Ex, int x)
{
	card_your_move.first = Ex.get_hand_you()[x].get_suit();
	card_your_move.second = Ex.get_hand_you()[x].get_value();
	if (card_your_move.first == kozir_fin)
	{
		set_card_move_erase_you(card_your_move.first, card_your_move.second, Ex);
		return 0;
	}
	else
		return 1;
}
int choose_helper2(int y)
{
	string x;
	switch (y)
	{
	case 1:
		return 0;
	case 2:
	{
		x = your_move_you_helper1(x);
		switch (x[0])
		{
		case '1':
		{
			return 0;
		}
		case '2':
		{
			return 1;
		}
		}
	}
	case 3:
	{
		x = your_move_you_helper2(x);
		switch (x[0])
		{
		case '1':
		{
			return 0;
		}
		case '2':
		{
			return 1;
		}
		case '3':
		{
			return 2;
		}
		}
	}
	case 4:
	{

		x = your_move_you_helper3(x);
		switch (x[0])
		{
		case '1':
		{
			return 0;
		}
		case '2':
		{
			return 1;
		}
		case '3':
		{
			return 2;
		}
		case '4':
		{
			return 3;
		}
		}
	}
	case 5:
	{

		x = your_move_you_helper4(x);
		switch (x[0])
		{
		case '1':
		{
			return 0;
		}
		case '2':
		{
			return 1;
		}
		case '3':
		{
			return  2;
		}
		case '4':
		{
			return  3;
		}
		case '5':
		{
			return 4;
		}
		}
	}
	case 6:
	{
		x = your_move_you_helper5(x);
		switch (x[0])
		{
		case '1':
		{
			return 0;
		}
		case '2':
		{
			return 1;
		}
		case '3':
		{
			return 2;
		}
		case '4':
		{
			return 3;
		}
		case '5':
		{
			return 4;
		}
		case '6':
		{
			return 5;
		}
		}
	}
	case 7:
	{
		x = your_move_you_helper6(x);
		switch (x[0])
		{
		case '1':
		{
			return 0;
		}
		case '2':
		{
			return  1;
		}
		case '3':
		{
			return 2;
		}
		case '4':
		{
			return 3;
		}
		case '5':
		{
			return 4;
		}
		case '6':
		{
			return 5;
		}
		case '7':
		{
			return 6;
		}
		}
	}
	case 8:
	{
		x = your_move_you_helper7(x);
		switch (x[0])
		{
		case '1':
		{
			return 0;
		}
		case '2':
		{
			return 1;
		}
		case '3':
		{
			return 2;
		}
		case '4':
		{
			return 3;
		}
		case '5':
		{
			return 4;
		}
		case '6':
		{
			return 5;
		}
		case '7':
		{
			return 6;
		}
		case '8':
		{
			return 7;
		}
		}
	}
	case 9:
	{
		x = your_move_you_helper8(x);
		switch (x[0])
		{
		case '1':
		{
			return 0;
		}
		case '2':
		{
			return 1;
		}
		case '3':
		{
			return 2;
		}
		case '4':
		{
			return 3;
		}
		case '5':
		{
			return 4;
		}
		case '6':
		{
			return 5;
		}
		case '7':
		{
			return 6;
		}
		case '8':
		{
			return 7;
		}
		case '9':
		{
			return 8;
		}
		}
	}
	case 10:
	{
		x = your_move_you_helper8(x);
		switch (x[0])
		{
		case '1':
		{
			if (x[1] == '0')
			{
				return 9;
			}
			else
			{
				return  0;
			}
		}
		case '2':
		{
			return 1;
		}
		case '3':
		{
			return 2;
		}
		case '4':
		{
			return 3;
		}
		case '5':
		{
			return 4;
		}
		case '6':
		{
			return 5;
		}
		case '7':
		{
			return 6;
		}
		case '8':
		{
			return 7;
		}
		case '9':
		{
			return 8;
		}
		}
	}
	}
}
bool choose_helper1(int y, Game&Ex)
{
	string x;
	switch (y)
	{
	case 1:
		return your_move_after_comp_choice2(Ex, 0);
	case 2:
	{
		x = your_move_you_helper1(x);
		switch (x[0])
		{
		case '1':
		{
			return your_move_after_comp_choice2(Ex, 0);
		}
		case '2':
		{
			return your_move_after_comp_choice2(Ex, 1);
		}
		}
	}
	case 3:
	{
		x = your_move_you_helper2(x);
		switch (x[0])
		{
		case '1':
		{
			return your_move_after_comp_choice2(Ex, 0);
		}
		case '2':
		{
			return your_move_after_comp_choice2(Ex, 1);
		}
		case '3':
		{
			return your_move_after_comp_choice2(Ex, 2);
		}
		}
	}
	case 4:
	{

		x = your_move_you_helper3(x);
		switch (x[0])
		{
		case '1':
		{
			return your_move_after_comp_choice2(Ex, 0);
		}
		case '2':
		{
			return your_move_after_comp_choice2(Ex, 1);
		}
		case '3':
		{
			return your_move_after_comp_choice2(Ex, 2);
		}
		case '4':
		{
			return your_move_after_comp_choice2(Ex, 3);
		}
		}
	}
	case 5:
	{

		x = your_move_you_helper4(x);
		switch (x[0])
		{
		case '1':
		{
			return your_move_after_comp_choice2(Ex, 0);
		}
		case '2':
		{
			return your_move_after_comp_choice2(Ex, 1);
		}
		case '3':
		{
			return your_move_after_comp_choice2(Ex, 2);
		}
		case '4':
		{
			return your_move_after_comp_choice2(Ex, 3);
		}
		case '5':
		{
			return your_move_after_comp_choice2(Ex, 4);
		}
		}
	}
	case 6:
	{
		x = your_move_you_helper5(x);
		switch (x[0])
		{
		case '1':
		{
			return your_move_after_comp_choice2(Ex, 0);
		}
		case '2':
		{
			return your_move_after_comp_choice2(Ex, 1);
		}
		case '3':
		{
			return your_move_after_comp_choice2(Ex, 2);
		}
		case '4':
		{
			return your_move_after_comp_choice2(Ex, 3);
		}
		case '5':
		{
			return your_move_after_comp_choice2(Ex, 4);
		}
		case '6':
		{
			return your_move_after_comp_choice2(Ex, 5);
		}
		}
	}
	case 7:
	{
		x = your_move_you_helper6(x);
		switch (x[0])
		{
		case '1':
		{
			return your_move_after_comp_choice2(Ex, 0);
		}
		case '2':
		{
			return your_move_after_comp_choice2(Ex, 1);
		}
		case '3':
		{
			return your_move_after_comp_choice2(Ex, 2);
		}
		case '4':
		{
			return your_move_after_comp_choice2(Ex, 3);
		}
		case '5':
		{
			return your_move_after_comp_choice2(Ex, 4);
		}
		case '6':
		{
			return your_move_after_comp_choice2(Ex, 5);
		}
		case '7':
		{
			return your_move_after_comp_choice2(Ex, 6);
		}
		}
	}
	case 8:
	{
		x = your_move_you_helper7(x);
		switch (x[0])
		{
		case '1':
		{
			return your_move_after_comp_choice2(Ex, 0);
		}
		case '2':
		{
			return your_move_after_comp_choice2(Ex, 1);
		}
		case '3':
		{
			return your_move_after_comp_choice2(Ex, 2);
		}
		case '4':
		{
			return your_move_after_comp_choice2(Ex, 3);
		}
		case '5':
		{
			return your_move_after_comp_choice2(Ex, 4);
		}
		case '6':
		{
			return your_move_after_comp_choice2(Ex, 5);
		}
		case '7':
		{
			return your_move_after_comp_choice2(Ex, 6);
		}
		case '8':
		{
			return your_move_after_comp_choice2(Ex, 7);
		}
		}
	}
	case 9:
	{
		x = your_move_you_helper8(x);
		switch (x[0])
		{
		case '1':
		{
			return your_move_after_comp_choice2(Ex, 0);
		}
		case '2':
		{
			return your_move_after_comp_choice2(Ex, 1);
		}
		case '3':
		{
			return your_move_after_comp_choice2(Ex, 2);
		}
		case '4':
		{
			return your_move_after_comp_choice2(Ex, 3);
		}
		case '5':
		{
			return your_move_after_comp_choice2(Ex, 4);
		}
		case '6':
		{
			return your_move_after_comp_choice2(Ex, 5);
		}
		case '7':
		{
			return your_move_after_comp_choice2(Ex, 6);
		}
		case '8':
		{
			return your_move_after_comp_choice2(Ex, 7);
		}
		case '9':
		{
			return your_move_after_comp_choice2(Ex, 8);
		}
		}
	}
	case 10:
	{
		x = your_move_you_helper9(x);
		switch (x[0])
		{
		case '1':
		{
			if (x[1] == '0')
			{
				return your_move_after_comp_choice2(Ex, 9);
			}
			else
			{
				return your_move_after_comp_choice2(Ex, 0);
			}
		}
		case '2':
		{
			return your_move_after_comp_choice2(Ex, 1);
		}
		case '3':
		{
			return your_move_after_comp_choice2(Ex, 2);
		}
		case '4':
		{
			return your_move_after_comp_choice2(Ex, 3);
		}
		case '5':
		{
			return your_move_after_comp_choice2(Ex, 4);
		}
		case '6':
		{
			return your_move_after_comp_choice2(Ex, 5);
		}
		case '7':
		{
			return your_move_after_comp_choice2(Ex, 6);
		}
		case '8':
		{
			return your_move_after_comp_choice2(Ex, 7);
		}
		case '9':
		{
			return your_move_after_comp_choice2(Ex, 8);
		}
		}
	}
	}
}
bool your_move_after_comp_choice1(vector<pair<char, int>>&Ex1, Game&Ex)
{
	bool x_greater = 0;
	string x;
	bool x_ind = 0;
	if (Ex1.size())
	{
		x_greater = check_greater_your_move(Ex1, Ex);
		int res = 0;
		switch (Ex.get_hand_you().size())
		{
		case 1:
		{
			card_your_move.first = Ex.get_hand_you()[0].get_suit();
			card_your_move.second = Ex.get_hand_you()[0].get_value();
			set_card_move_erase_you(card_your_move.first, card_your_move.second, Ex);
			if (card_your_move.first == kozir_fin)
			{
				if (helper2(card_your_move.second.data()[0], 1) > helper2(card_comp_move.second.data()[0], 1))
					return 0;
				else
					return 1;
			}
			else
				return 0;
		}
		case 2:
		{
			while (1)
			{
				x = your_move_you_helper1(x);
				switch (x[0])
				{
				case '1':
				{
				   res = move_you_after_comp_helper(x_greater, 0, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '2':
				{
					 res = move_you_after_comp_helper(x_greater, 1, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				}
			}
		}
		case 3:
			while (1)
			{
				x = your_move_you_helper2(x);
				switch (x[0])
				{
				case '1':
				{
					res = move_you_after_comp_helper(x_greater, 0, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '2':
				{
					res = move_you_after_comp_helper(x_greater, 1, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '3':
				{
					res = move_you_after_comp_helper(x_greater, 2, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				}
			}
		case 4:
			while (1)
			{
				x = your_move_you_helper3(x);
				switch (x[0])
				{
				case '1':
				{
					res = move_you_after_comp_helper(x_greater, 0, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '2':
				{
					res = move_you_after_comp_helper(x_greater, 1, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '3':
				{
					res = move_you_after_comp_helper(x_greater, 2, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '4':
				{
					res = move_you_after_comp_helper(x_greater, 3, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				}
			}
		case 5:
			while (1)
			{
				x = your_move_you_helper4(x);
				switch (x[0])
				{
				case '1':
				{
					res = move_you_after_comp_helper(x_greater, 0, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '2':
				{
					res = move_you_after_comp_helper(x_greater, 1, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '3':
				{
					res = move_you_after_comp_helper(x_greater, 2, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '4':
				{
					res = move_you_after_comp_helper(x_greater, 3, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '5':
				{
					res = move_you_after_comp_helper(x_greater, 4, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				}
			}
		case 6:
			while (1)
			{
				x = your_move_you_helper5(x);
				switch (x[0])
				{
				case '1':
				{
					res = move_you_after_comp_helper(x_greater, 0, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '2':
				{
					res = move_you_after_comp_helper(x_greater, 1, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '3':
				{
					res = move_you_after_comp_helper(x_greater, 2, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '4':
				{
					res = move_you_after_comp_helper(x_greater, 3, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '5':
				{
					res = move_you_after_comp_helper(x_greater, 4, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '6':
				{
					res = move_you_after_comp_helper(x_greater, 5, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				}
			}
		case 7:
			while (1)
			{
				x = your_move_you_helper6(x);
				switch (x[0])
				{
				case '1':
				{
					res = move_you_after_comp_helper(x_greater, 0, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '2':
				{
					res = move_you_after_comp_helper(x_greater, 1, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '3':
				{
					res = move_you_after_comp_helper(x_greater, 2, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '4':
				{
					res = move_you_after_comp_helper(x_greater, 3, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '5':
				{
					res = move_you_after_comp_helper(x_greater, 4, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '6':
				{
					res = move_you_after_comp_helper(x_greater, 5, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '7':
				{
					res = move_you_after_comp_helper(x_greater, 6, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				}
			}
		case 8:
			while (1)
			{
				x = your_move_you_helper7(x);
				switch (x[0])
				{
				case '1':
				{
					res = move_you_after_comp_helper(x_greater, 0, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '2':
				{
					res = move_you_after_comp_helper(x_greater, 1, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '3':
				{
					res = move_you_after_comp_helper(x_greater, 2, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '4':
				{
					res = move_you_after_comp_helper(x_greater, 3, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '5':
				{
					res = move_you_after_comp_helper(x_greater, 4, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '6':
				{
					res = move_you_after_comp_helper(x_greater, 5, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '7':
				{
					res = move_you_after_comp_helper(x_greater, 6, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '8':
				{
					res = move_you_after_comp_helper(x_greater, 7, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				}
			}
		case 9:
			while (1)
			{
				x = your_move_you_helper8(x);
				switch (x[0])
				{
				case '1':
				{
					res = move_you_after_comp_helper(x_greater, 0, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '2':
				{
					res = move_you_after_comp_helper(x_greater, 1, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '3':
				{
					res = move_you_after_comp_helper(x_greater, 2, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '4':
				{
					res = move_you_after_comp_helper(x_greater, 3, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '5':
				{
					res = move_you_after_comp_helper(x_greater, 4, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '6':
				{
					res = move_you_after_comp_helper(x_greater, 5, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '7':
				{
					res = move_you_after_comp_helper(x_greater, 6, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '8':
				{
					res = move_you_after_comp_helper(x_greater, 7, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '9':
				{
					res = move_you_after_comp_helper(x_greater, 8, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				}
			}
		case 10:
			while (1)
			{
				x = your_move_you_helper9(x);
				switch (x[0])
				{
				case '1':
				{
					if (x[1] == '0')
					{
						res = move_you_after_comp_helper(x_greater, 9, Ex);
						if (!res)
							return 0;
						if (res == 1)
							return 1;
						else
							break;
					}
					else
					{
						res = move_you_after_comp_helper(x_greater, 0, Ex);
						if (!res)
							return 0;
						if (res == 1)
							return 1;
						else
							break;
					}
				}
				case '2':
				{
					res = move_you_after_comp_helper(x_greater, 1, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '3':
				{
					res = move_you_after_comp_helper(x_greater, 2, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '4':
				{
					res = move_you_after_comp_helper(x_greater, 3, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '5':
				{
					res = move_you_after_comp_helper(x_greater, 4, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '6':
				{
					res = move_you_after_comp_helper(x_greater, 5, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '7':
				{
					res = move_you_after_comp_helper(x_greater, 6, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '8':
				{
					res = move_you_after_comp_helper(x_greater, 7, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				case '9':
				{
					res = move_you_after_comp_helper(x_greater, 8, Ex);
					if (!res)
						return 0;
					if (res == 1)
						return 1;
					else
						break;
				}
				}
			}
		}
	}
	else
		return choose_helper1(Ex.get_hand_you().size(), Ex);
}
bool choose_helper3(vector<pair<char, int>>&Ex1, Game&Ex)
{
	if (!Ex1.size())
	{
		return choose_helper1(Ex.get_hand_you().size(), Ex);
	}
	else
	{
		while (1)
		{
			int x = choose_helper2(Ex.get_hand_you().size());
			bool x1 = your_move_after_comp_choice3(Ex, x);
			if (!x1)
				return 0;
		}
	}
}
bool your_move_after_comp(Game &Ex)
{
	split_suits_your_move(Ex);
	sort(Ex.get_hearts_you_move().begin(), Ex.get_hearts_you_move().end(), compare0);
	sort(Ex.get_diamonds_you_move().begin(), Ex.get_diamonds_you_move().end(), compare0);
	sort(Ex.get_clubs_you_move().begin(), Ex.get_clubs_you_move().end(), compare0);
	sort(Ex.get_speads_you_move().begin(), Ex.get_speads_you_move().end(), compare0);
	
	if (Ex.get_card_comp_move().get_suit() == kozir_fin)
	{
		switch (kozir_fin)
		{
		case 3:
			return your_move_after_comp_choice1(Ex.get_hearts_you_move(), Ex);
		case 4:
			return your_move_after_comp_choice1(Ex.get_diamonds_you_move(), Ex);
		case 5:
			return your_move_after_comp_choice1(Ex.get_clubs_you_move(), Ex);
		case 6:
			return your_move_after_comp_choice1(Ex.get_speads_you_move(), Ex);
		}
	}
	else
	{
		switch (Ex.get_card_comp_move().get_suit())
		{
		case 3:
		{
			if (!Ex.get_hearts_you_move().size())
			{
				switch (kozir_fin)
				{
				case 4:
					return choose_helper3(Ex.get_diamonds_you_move(), Ex);
				   
				case 5:
					return choose_helper3(Ex.get_clubs_you_move(), Ex);
				case 6:
					return choose_helper3(Ex.get_speads_you_move(), Ex);
				}
			}
			else
			{
				while (1)
				{
					int x = choose_helper2(Ex.get_hand_you().size());
					if (Ex.get_hand_you()[x].get_suit() == 3)
						return your_move_after_comp_choice21(Ex, x);
				}
			}
		}
		case 4:
		{
			if (!Ex.get_diamonds_you_move().size())
			{
				switch (kozir_fin)
				{
				case 3:
					return choose_helper3(Ex.get_hearts_you_move(), Ex);

				case 5:
					return choose_helper3(Ex.get_clubs_you_move(), Ex);
				case 6:
					return choose_helper3(Ex.get_speads_you_move(), Ex);
				}
			}
			else
			{
				while (1)
				{
					int x = choose_helper2(Ex.get_hand_you().size());
					if (Ex.get_hand_you()[x].get_suit() == 4)
						return your_move_after_comp_choice21(Ex, x);
				}
			}
		}
		case 5:
		{
			if (!Ex.get_clubs_you_move().size())
			{
				switch (kozir_fin)
				{
				case 3:
					return choose_helper3(Ex.get_hearts_you_move(), Ex);

				case 4:
					return choose_helper3(Ex.get_diamonds_you_move(), Ex);
				case 6:
					return choose_helper3(Ex.get_speads_you_move(), Ex);
				}
			}
			else
			{
				while (1)
				{
					int x = choose_helper2(Ex.get_hand_you().size());
					if (Ex.get_hand_you()[x].get_suit() == 5)
						return your_move_after_comp_choice21(Ex, x);
				}
			}
		}
		case 6:
		{
			if (!Ex.get_speads_you_move().size())
			{
				switch (kozir_fin)
				{
				case 3:
					return choose_helper3(Ex.get_hearts_you_move(), Ex);

				case 4:
					return choose_helper3(Ex.get_diamonds_you_move(), Ex);
				case 5:
					return choose_helper3(Ex.get_clubs_you_move(), Ex);
				}
			}
			else
			{
				while (1)
				{
					int x = choose_helper2(Ex.get_hand_you().size());
					if (Ex.get_hand_you()[x].get_suit() == 6)
						return your_move_after_comp_choice21(Ex, x);
				}
			}
		}
		}
	}
}
bool say_bella()
{
	string x;
	regex a("1|2");
	cout << "1 Announce  2 Do not announce\n";
	while (1)
	{
		getline(cin, x);
		if (regex_match(x, a))
		{
			if (x == "1")
				return 1;
			else
				return 0;
		}
	}
}
int count_books(int& x,vector<pair<Card, Card>>&Ex)
{
	if (Ex.size())
	{
		bool x1 = 0;
		vector<pair<Card, Card>>::iterator it = Ex.begin();
		for (; it != Ex.end(); it++)
		{
			if ((*it).first.get_suit() == kozir_fin && (*it).first.get_value() == "J"||((*it).second.get_suit()==kozir_fin&&(*it).second.get_value()=="J"))
			{
				x += 20;
				x1 = 1;
			}
			if (((*it).first.get_suit() == kozir_fin && (*it).first.get_value() == "9") || ((*it).second.get_suit() == kozir_fin && (*it).second.get_value() == "9"))
				x += 14;
			if ((*it).first.get_value() == "7" || (*it).first.get_value() == "8" || (*it).first.get_value() == "9")
				;
			else if ((*it).first.get_value() == "J")
				x += 2;
			else if ((*it).first.get_value() == "Q")
				x += 3;
			else if ((*it).first.get_value() == "K")
				x += 4;
			else if ((*it).first.get_value() == "10")
				x += 10;
			else if ((*it).first.get_value() == "A")
				x += 11;
			if ((*it).second.get_value() == "7" || (*it).second.get_value() == "8" || (*it).second.get_value() == "9")
				;
			else if ((*it).second.get_value() == "J")
				x += 2;
			else if ((*it).second.get_value() == "Q")
				x += 3;
			else if ((*it).second.get_value() == "K")
				x += 4;
			else if ((*it).second.get_value() == "10")
				x += 10;
			else if ((*it).second.get_value() == "A")
				x += 11;
		}
		if (x1)
			x -= 2;
		return x;
	}
	else
		return -1;
}
void erase_books(Game&Ex)
{
	if (Ex.get_your_books().size())
		Ex.get_your_books().erase(Ex.get_your_books().begin(), Ex.get_your_books().end());
	if (Ex.get_comp_books().size())
		Ex.get_comp_books().erase(Ex.get_comp_books().begin(), Ex.get_comp_books().end());
}
void main()
{
	srand(time(NULL));
	int sum_you = 0;
	int sum_comp = 0;
	int total_sum_you = 0;
	int total_sum_comp = 0;
	bool turn = 0;
	char kozir1;
	bool you_play = 0;
	bool comp_play = 0;
	int count_bajt_you = 0;
	int count_bajt_comp = 0;
	Game Ex;
	Ex.get_deck().assign({ Card(3, "7"), Card(3, "8"), Card(3, "9"), Card(3, "10"), Card(3, "J"), Card(3, "Q"), Card(3, "K"), Card(3, "A"),
		Card(4, "7"), Card(4, "8"), Card(4, "9"), Card(4, "10"), Card(4, "J"), Card(4, "Q"), Card(4, "K"), Card(4, "A"),
		Card(5, "7"), Card(5, "8"), Card(5, "9"), Card(5, "10"), Card(5, "J"), Card(5, "Q"), Card(5, "K"), Card(5, "A"),
		Card(6, "7"), Card(6, "8"), Card(6, "9"), Card(6, "10"), Card(6, "J"), Card(6, "Q"), Card(6, "K"), Card(6, "A") });
	while (1)
	{
		while (total_sum_you < 1001 && total_sum_comp < 1001)
		{
			random_shuffle(Ex.get_deck().begin(), Ex.get_deck().end());
			if (!turn)
			{
				int index = 32;
				for (int i = 0; i < 2; i++)
				{
				for (int i = 0; i < 3; i++)
				Ex.get_hand_you().push_back(Ex.get_deck()[--index]);
				for (int i = 0; i < 3; i++)
				Ex.get_hand_comp().push_back(Ex.get_deck()[--index]);
				}
				kozir.first = Ex.get_deck()[--index].get_suit();
				kozir.second = Ex.get_deck()[index].get_value();
				Card obj(kozir.first, kozir.second);
				sort(Ex.get_hand_you().begin(), Ex.get_hand_you().end(), compare);
				sort(Ex.get_hand_you().begin(), Ex.get_hand_you().end(), compare1);
				sort(Ex.get_hand_comp().begin(), Ex.get_hand_comp().end(), compare);
				sort(Ex.get_hand_comp().begin(), Ex.get_hand_comp().end(), compare1);
				vector<Card>::iterator it = Ex.get_hand_you().begin();
				for (; it < Ex.get_hand_you().end(); it++)
					cout << it;
				cout << "\t\t" << "Svetit: " << kozir.first << " " << kozir.second << endl;
				it = Ex.get_hand_comp().begin();
				for (; it < Ex.get_hand_comp().end(); it++)
					cout << it;
				cout << endl << "Your word\n";
				if (!ras_pas_you_kryg_1())
				{
					if (!ras_pas_comp_kryg_1_objaz(Ex.get_hand_comp()))
					{
						cout << "Comp says pass\n" << endl;
						if (!ras_pas_you_kryg2(turn))
						{
							compare_priority_comp_cryg2_objaz(Ex.get_hand_comp());
							cout << "Comp plays " << kozir_fin << endl;
							comp_play = 1;
						}
						else
						{
							cout << "You play " << kozir_fin << endl;
							you_play = 1;
						}
					}
					else
					{
						cout << "Comp plays " << kozir_fin << endl;
						comp_play = 1;
						split_suits_comp(Ex);
						bool x1 = check_deb_comp(Ex, kozir_fin);
						if (x1)
						{
							cout << "Comp has deberts: ";
							cout << kozir_fin << " " << "9 10 J Q K A" << endl;
							total_sum_comp = 1001;
							break;
						}
						else
							clear_suits_comp(Ex);
						vector<Card>::iterator it = find_if(Ex.get_hand_comp().begin(), Ex.get_hand_comp().end(), compare16);
						if (it != Ex.get_hand_comp().end())
						{
							bool x1 = check_50_7(Ex.get_hand_comp());
							if (x1)
							{
								swap(obj, (*it));
								sort(Ex.get_hand_comp().begin(), Ex.get_hand_comp().end(), compare);
								sort(Ex.get_hand_comp().begin(), Ex.get_hand_comp().end(), compare1);
								split_suits_comp(Ex);
								bool x1 = check_deb_comp(Ex, kozir_fin);
								if (x1)
								{
									cout << "Comp has deberts: ";
									cout << kozir_fin << " " << "9 10 J Q K A" << endl;
									total_sum_comp = 1001;
									break;
								}
								else
									clear_suits_comp(Ex);
							}
							else
							{
								if (kozir.second == "J")
								{
									swap(obj, (*it));
									sort(Ex.get_hand_comp().begin(), Ex.get_hand_comp().end(), compare);
									sort(Ex.get_hand_comp().begin(), Ex.get_hand_comp().end(), compare1);
								}
							}
						}

					}
				}
				else
				{
					cout << "You play " << kozir_fin << endl;
					you_play = 1;
					split_suits_you(Ex);
					bool x1 = check_deb_you(Ex, kozir_fin);
					if (x1)
					{
						cout << "Wow, you have deberts: ";
						cout << kozir_fin << " " << "9 10 J Q K A" << endl;
						total_sum_comp = 1001;
						break;
					}
					else
						clear_suits_you(Ex);
					vector<Card>::iterator it = find_if(Ex.get_hand_you().begin(), Ex.get_hand_you().end(), compare16);
					if (it != Ex.get_hand_you().end())
					{
						cout << "You have 7 " << kozir.first << " Want to swap?\n1 - Yes   2 - No:";
						string x;
						regex a("1|2");
						while (1)
						{
							getline(cin, x);
							if (regex_match(x, a))
								break;
							else
								continue;
						}
						if (x == "1")
						{
							swap(obj, (*it));
							sort(Ex.get_hand_you().begin(), Ex.get_hand_you().end(), compare);
							sort(Ex.get_hand_you().begin(), Ex.get_hand_you().end(), compare1);
							split_suits_you(Ex);
							bool x1 = check_deb_you(Ex, kozir_fin);
							if (x1)
							{
								cout << "Wow, you have deberts: ";
								cout << kozir_fin << " " << "9 10 J Q K A" << endl;
								total_sum_you = 1001;
								break;
							}
							else
								clear_suits_you(Ex);
						}
					}
				}
				for (int i = 0; i < 4; i++)
					Ex.get_hand_you().push_back(Ex.get_deck()[--index]);
					for (int i = 0; i < 4; i++)
					Ex.get_hand_comp().push_back(Ex.get_deck()[--index]);
				switch (kozir_fin)
				{
				case 3:
					index_suit = 0;
					break;
				case 4:
					index_suit = 1;
					break;
				case 5:
					index_suit = 2;
					break;
				case 6:
					index_suit = 3;
				}
				sort(Ex.get_hand_you().begin(), Ex.get_hand_you().end(), compare);
				sort(Ex.get_hand_comp().begin(), Ex.get_hand_comp().end(), compare);
				sort(Ex.get_hand_you().begin(), Ex.get_hand_you().end(), compare1);
				sort(Ex.get_hand_comp().begin(), Ex.get_hand_comp().end(), compare1);
				priority_you = check_9_J_QK_else_suit(Ex.get_hand_you());
				priority_comp = check_9_J_QK_else_suit(Ex.get_hand_comp());
				it = Ex.get_hand_you().begin();
				for (; it < Ex.get_hand_you().end(); it++)
					cout << it;
				cout << endl << "\t\tSvetit " << obj.get_suit() << " " << obj.get_value() << "    " << Ex.get_deck()[0].get_suit() << " " << Ex.get_deck()[0].get_value() << endl;
				it = Ex.get_hand_comp().begin();
				for (; it < Ex.get_hand_comp().end(); it++)
					cout << it;
				cout << endl;
				split_suits_you(Ex);
				split_suits_comp(Ex);
				check_words(Ex.get_hearts_you(), Ex.get_diamonds_you(), Ex.get_clubs_you(), Ex.get_speads_you(), Ex.get_hearts_comp(), Ex.get_diamonds_comp(), Ex.get_clubs_comp(), Ex.get_speads_comp(), Ex);
				words_comp = pre_words(Ex.get_priority_you(), Ex.get_priority_comp(), turn, Ex, sum_you, sum_comp);
				cout << "Vash Xod:\n";
				bool x1 = 0;
				for (int j = 0; j < 10; j++)
				{
					if (!j)
					{
						split_suits_comp_move_dop(Ex);
						size_hearts_comp = Ex.get_hearts_comp_dop().size();
						size_diamonds_comp = Ex.get_diamonds_comp_dop().size();
						size_clubs_comp = Ex.get_clubs_comp_dop().size();
						size_speads_comp = Ex.get_speads_comp_dop().size();
					}
					if (!x1)
					{
						x1 = your_move_you(Ex, Ex.get_priority_you(), Ex.get_priority_comp(), turn);
						if (Ex.get_card_your_move().get_suit() == kozir_fin && ((Ex.get_card_your_move().get_value() == "Q") || (Ex.get_card_your_move().get_value() == "K")))
						{
							if (++bella_you == 2)
							{
								cout << "You have bella.\n";
								if (say_bella())
									sum_you += 20;
							}
						}
						cout << "   Comp: " << Ex.get_card_comp_move().get_suit() << " " << Ex.get_card_comp_move().get_value() << endl;
						if (Ex.get_card_comp_move().get_suit() == kozir_fin && ((Ex.get_card_comp_move().get_value() == "Q") || (Ex.get_card_comp_move().get_value() == "K")))
						{
							if (++bella_comp == 2)
							{
								cout << "Comp has bella\n";
								sum_comp += 20;
							}
						}
						if (!x1)
						{
							cout << "Your Book.\n";
							Ex.get_your_books().push_back(pair<Card, Card>(Card(Ex.get_card_your_move().get_suit(), Ex.get_card_your_move().get_value()), Card(Ex.get_card_comp_move().get_suit(), Ex.get_card_comp_move().get_value())));
						}
						else
						{
							cout << "Comp's Book.\n";
							Ex.get_comp_books().push_back(pair<Card, Card>(Card(Ex.get_card_your_move().get_suit(), Ex.get_card_your_move().get_value()), Card(Ex.get_card_comp_move().get_suit(), Ex.get_card_comp_move().get_value())));
						}
					}
					else
					{
						comp_move_comp(Ex);
						cout << "Comp: " << Ex.get_card_comp_move().get_suit() << " " << Ex.get_card_comp_move().get_value();
						if (Ex.get_card_comp_move().get_suit() == kozir_fin && ((Ex.get_card_comp_move().get_value() == "Q") || (Ex.get_card_comp_move().get_value() == "K")))
						{
							if (++bella_comp == 2)
							{
								cout << "Comp has bella.\n";
								sum_comp += 20;
							}
						}
						x1 = your_move_after_comp(Ex);
						cout << "You: " << Ex.get_card_your_move().get_suit() << " " << Ex.get_card_your_move().get_value() << endl;
						if (v_kozir1 == 0 && Ex.get_card_comp_move().get_suit() != kozir_fin&&Ex.get_card_your_move().get_suit() == kozir_fin)
							v_kozir1 = Ex.get_card_comp_move().get_suit();
						else if (v_kozir2 == 0 && Ex.get_card_comp_move().get_suit() != kozir_fin&&Ex.get_card_your_move().get_suit() == kozir_fin)
							v_kozir2 = 0;
						else if (v_kozir3 == 0 && Ex.get_card_comp_move().get_suit() != kozir_fin&&Ex.get_card_your_move().get_suit() == kozir_fin)
							v_kozir3 = Ex.get_card_your_move().get_suit();
						if (Ex.get_card_your_move().get_suit() == kozir_fin && ((Ex.get_card_your_move().get_value() == "Q") || (Ex.get_card_your_move().get_value() == "K")))
						{
							if (++bella_you == 2)
							{
								cout << "You have bella.\n";
								if (say_bella())
									sum_you += 20;
							}
						}
						if (!x1)
						{
							cout << "Your Book.\n";
							Ex.get_your_books().push_back(pair<Card, Card>(Card(Ex.get_card_your_move().get_suit(), Ex.get_card_your_move().get_value()), Card(Ex.get_card_comp_move().get_suit(), Ex.get_card_comp_move().get_value())));
						}
						else
						{
							cout << "Comp's Book.\n";
							Ex.get_comp_books().push_back(pair<Card, Card>(Card(Ex.get_card_your_move().get_suit(), Ex.get_card_your_move().get_value()), Card(Ex.get_card_comp_move().get_suit(), Ex.get_card_comp_move().get_value())));
						}
					}
					if (j == 9 && !x1)
					{
						sum_you += 10;
						cout << "Vash Last.\n";
					}
					else if (j == 9 && x1)
					{
						sum_comp += 10;
						cout << "Last got the comp.\n";
					}
				}
				erase_suits_move(Ex.get_hearts_comp_dop(), Ex.get_diamonds_comp_dop(), Ex.get_clubs_comp_dop(), Ex.get_speads_comp_dop());
				erase_suits_move(Ex.get_hearts_you_move(), Ex.get_diamonds_you_move(), Ex.get_clubs_you_move(), Ex.get_speads_you_move());
				erase_suits_move(Ex.get_hearts_comp_move(), Ex.get_diamonds_comp_move(), Ex.get_clubs_comp_move(), Ex.get_speads_comp_move());
				clear_suits_you(Ex);
				clear_suits_comp(Ex);
				clear_50_20_you_comp(Ex);
				bella_comp = 0;
				bella_you = 0;
				v_kozir1 = 0;
				v_kozir2 = 0;
				v_kozir3 = 0;
				size_hearts_comp = 0;
				size_diamonds_comp = 0;
				size_clubs_comp = 0;
				size_speads_comp = 0;
				words_comp = 0;
				turn = 1;
				int you_res = 0;
				you_res=count_books(you_res, Ex.get_your_books());
				int comp_res = 0;
				comp_res=count_books(comp_res, Ex.get_comp_books());
				erase_books(Ex);
				cout << "This hand:\n";
				if (you_res == -1)
				{
					cout << "Vam LbIza.\n";
					cout << "Comp: " << sum_comp+comp_res << endl;
					total_sum_you -= 50;
				}
				else if (comp_res==-1)
				{
						cout << "You: " << sum_you+you_res << endl;
						cout << "Compy LbIza.\n";
						total_sum_comp -= 50;
				}
				else if (you_play && (sum_comp+comp_res > sum_you+you_res))
				{
					cout << "Vam Bajtello.\n";
					total_sum_comp += sum_you+you_res+sum_comp+comp_res;
					++count_bajt_you;
					if (count_bajt_you == 2)
					{
						cout << "Second bajt == -100.\n";
						total_sum_you -= 100;
						count_bajt_you = 0;
					}

				}
				else if (you_play && (sum_comp + comp_res < sum_you + you_res))
				{
					cout << "You: " << sum_you + you_res << endl;
					cout << "Comp: " << sum_comp + comp_res << endl;
					total_sum_you += sum_you + you_res;
					total_sum_comp += sum_comp + comp_res;
				}
				else if (comp_play && (sum_comp + comp_res < sum_you + you_res))
				{
					cout << "Compy Bajtello.\n";
					total_sum_you += sum_comp + comp_res + sum_you + you_res;
					++count_bajt_comp;
					if (count_bajt_comp == 2)
					{
						cout << "Second bajt == -100.\n";
						total_sum_comp -= 100;
						count_bajt_comp = 0;
					}
				}
				else if (comp_play && (sum_comp + comp_res > sum_you + you_res))
				{
					cout << "You: " << sum_you + you_res << endl;
					cout << "Comp: " << sum_comp + comp_res << endl;
					total_sum_you += sum_you + you_res;
					total_sum_comp += sum_comp + comp_res;
				}
				cout << "TOTAL:\n";
				cout << "YOU: " << total_sum_you << endl;
				cout << "Comp: " << total_sum_comp << endl;
				you_play = 0;
				comp_play = 0;
				sum_you = 0;
				sum_comp = 0;
			}
			else
			{
				int index = 32;
				for (int i = 0; i < 2; i++)
				{
					for (int i = 0; i < 3; i++)
						Ex.get_hand_comp().push_back(Ex.get_deck()[--index]);
					for (int i = 0; i < 3; i++)
						Ex.get_hand_you().push_back(Ex.get_deck()[--index]);
				}
				kozir.first = Ex.get_deck()[--index].get_suit();
				kozir.second = Ex.get_deck()[index].get_value();
				Card obj(kozir.first, kozir.second);
				sort(Ex.get_hand_you().begin(), Ex.get_hand_you().end(), compare);
				sort(Ex.get_hand_you().begin(), Ex.get_hand_you().end(), compare1);
				sort(Ex.get_hand_comp().begin(), Ex.get_hand_comp().end(), compare);
				sort(Ex.get_hand_comp().begin(), Ex.get_hand_comp().end(), compare1);
				vector<Card>::iterator it = Ex.get_hand_you().begin();
				for (; it < Ex.get_hand_you().end(); it++)
					cout << it;
				cout << "\t\t" << "Svetit: " << kozir.first << " " << kozir.second << endl;
				it = Ex.get_hand_comp().begin();
				for (; it < Ex.get_hand_comp().end(); it++)
					cout << it;
				if (!ras_pas_comp_cryg1_no_objaz(Ex.get_hand_comp()))
				{
					cout << "Comp says pass.\n";
					if (!ras_pas_you_kryg_1())
					{
						cout << "You said pass\n" << endl;
						if (!ras_pas_comp_cryg2_no_objaz(Ex.get_hand_comp()))
						{
							cout << "Comp says pass.\n";
							ras_pas_you_kryg2(turn);
							cout << "You play " << kozir_fin << endl;
							you_play = 1;
						}
						else
						{
							cout << "Comp plays " << kozir_fin << endl;
							comp_play = 1;
						}
					}
					else
					{
						cout << "You play  " << kozir_fin << endl;
						you_play = 1;
						split_suits_you(Ex);
						bool x1 = check_deb_you(Ex, kozir_fin);
						if (x1)
						{
							cout << "You have deberts: ";
							cout << kozir_fin << " " << "9 10 J Q K A" << endl;
							total_sum_you = 1001;
							break;
						}
						else
							clear_suits_you(Ex);
						vector<Card>::iterator it = find_if(Ex.get_hand_you().begin(), Ex.get_hand_you().end(), compare16);
						if (it != Ex.get_hand_you().end())
						{
							cout << "You have 7 " << kozir.first << " Want to swap?\n1 - Yes   2 - No:";
							string x;
							regex a("1|2");
							while (1)
							{
								getline(cin, x);
								if (regex_match(x, a))
									break;
								else
									continue;
							}
							if (x == "1")
							{
								swap(obj, (*it));
								sort(Ex.get_hand_you().begin(), Ex.get_hand_you().end(), compare);
								sort(Ex.get_hand_you().begin(), Ex.get_hand_you().end(), compare1);
								split_suits_you(Ex);
								bool x1 = check_deb_you(Ex, kozir_fin);
								if (x1)
								{
									cout << "Wow, you have deberts: ";
									cout << kozir_fin << " " << "9 10 J Q K A" << endl;
									total_sum_you = 1001;
									break;
								}
								else
									clear_suits_you(Ex);
							}
						}
					}
				}
				else
				{
					cout << "Comp plays " << kozir_fin << endl;
					comp_play = 1;
					split_suits_comp(Ex);
					bool x1 = check_deb_comp(Ex, kozir_fin);
					if (x1)
					{
						cout << "Comp has deberts: ";
						cout << kozir_fin << " " << "9 10 J Q K A" << endl;
						total_sum_comp = 1001;
						break;
					}
					else
						clear_suits_comp(Ex);
					vector<Card>::iterator it = find_if(Ex.get_hand_comp().begin(), Ex.get_hand_comp().end(), compare16);
					if (it != Ex.get_hand_comp().end())
					{
						bool x1 = check_50_7(Ex.get_hand_comp());
						if (x1)
						{
							swap(obj, (*it));
							sort(Ex.get_hand_comp().begin(), Ex.get_hand_comp().end(), compare);
							sort(Ex.get_hand_comp().begin(), Ex.get_hand_comp().end(), compare1);
							split_suits_comp(Ex);
							vector<int>::iterator po = Ex.get_hearts_comp().begin();
							bool x1 = check_deb_comp(Ex, kozir_fin);
							if (x1)
							{
								cout << "Comp has deberts: ";
								cout << kozir_fin << " " << "9 10 J Q K A" << endl;
								total_sum_comp = 1001;
								break;
							}
							else
								clear_suits_comp(Ex);
						}
						else
						{
							if (kozir.second == "J")
							{
								swap(obj, (*it));
								sort(Ex.get_hand_comp().begin(), Ex.get_hand_comp().end(), compare);
								sort(Ex.get_hand_comp().begin(), Ex.get_hand_comp().end(), compare1);
							}
						}
					}
				}
				for (int i = 0; i < 4; i++)
					Ex.get_hand_comp().push_back(Ex.get_deck()[--index]);
				for (int i = 0; i < 4; i++)
					Ex.get_hand_you().push_back(Ex.get_deck()[--index]);
				switch (kozir_fin)
				{
				case 3:
					index_suit = 0;
					break;
				case 4:
					index_suit = 1;
					break;
				case 5:
					index_suit = 2;
					break;
				case 6:
					index_suit = 3;
				}
				sort(Ex.get_hand_you().begin(), Ex.get_hand_you().end(), compare);
				sort(Ex.get_hand_comp().begin(), Ex.get_hand_comp().end(), compare);
				sort(Ex.get_hand_you().begin(), Ex.get_hand_you().end(), compare1);
				sort(Ex.get_hand_comp().begin(), Ex.get_hand_comp().end(), compare1);
				priority_you = check_9_J_QK_else_suit(Ex.get_hand_you());
				priority_comp = check_9_J_QK_else_suit(Ex.get_hand_comp());
				it = Ex.get_hand_you().begin();
				for (; it < Ex.get_hand_you().end(); it++)
					cout << it;
				cout << endl << "\t\tSvetit " << obj.get_suit() << " " << obj.get_value() << "    " << Ex.get_deck()[0].get_suit() << " " << Ex.get_deck()[0].get_value() << endl;
				it = Ex.get_hand_comp().begin();
				for (; it < Ex.get_hand_comp().end(); it++)
					cout << it;
				cout << endl;
				split_suits_you(Ex);
				split_suits_comp(Ex);
				check_words(Ex.get_hearts_you(), Ex.get_diamonds_you(), Ex.get_clubs_you(), Ex.get_speads_you(), Ex.get_hearts_comp(), Ex.get_diamonds_comp(), Ex.get_clubs_comp(), Ex.get_speads_comp(), Ex);
				words_comp = pre_words(Ex.get_priority_you(), Ex.get_priority_comp(), turn, Ex, sum_you, sum_comp);
				bool x1 = 1;
				for (int j = 0; j < 10; j++)
				{
					if (!i)
					{
						split_suits_comp_move_dop(Ex);
						size_hearts_comp = Ex.get_hearts_comp_dop().size();
						size_diamonds_comp = Ex.get_diamonds_comp_dop().size();
						size_clubs_comp = Ex.get_clubs_comp_dop().size();
						size_speads_comp = Ex.get_speads_comp_dop().size();
					}
					if (!x1)
					{
						x1 = your_move_you(Ex, Ex.get_priority_you(), Ex.get_priority_comp(), turn);
						if (Ex.get_card_your_move().get_suit() == kozir_fin && ((Ex.get_card_your_move().get_value() == "Q") || (Ex.get_card_your_move().get_value() == "K")))
						{
							if (++bella_you == 2)
							{
								cout << "You have bella.\n";
								if (say_bella())
									sum_you += 20;
							}
						}
						cout << "   Comp: " << Ex.get_card_comp_move().get_suit() << " " << Ex.get_card_comp_move().get_value() << endl;
						if (Ex.get_card_comp_move().get_suit() == kozir_fin && ((Ex.get_card_comp_move().get_value() == "K") || (Ex.get_card_comp_move().get_value() == "Q")))
						{
							if (++bella_comp == 2)
							{
								cout << "Comp has bella\n";
								sum_comp += 20;
							}
						}
						if (!x1)
						{
							cout << "Your Book.\n";
							Ex.get_your_books().push_back(pair<Card, Card>(Card(Ex.get_card_your_move().get_suit(), Ex.get_card_your_move().get_value()), Card(Ex.get_card_comp_move().get_suit(), Ex.get_card_comp_move().get_value())));
						}
						else
						{
							cout << "Comp's Book.\n";
							Ex.get_comp_books().push_back(pair<Card, Card>(Card(Ex.get_card_your_move().get_suit(), Ex.get_card_your_move().get_value()), Card(Ex.get_card_comp_move().get_suit(), Ex.get_card_comp_move().get_value())));
						}
					}
					else
					{
						comp_move_comp(Ex);
						cout << "Comp: " << Ex.get_card_comp_move().get_suit() << " " << Ex.get_card_comp_move().get_value()<<endl;
						if (Ex.get_card_comp_move().get_suit() == kozir_fin && ((Ex.get_card_comp_move().get_value() == "K") || (Ex.get_card_comp_move().get_value() == "Q")))
						{
							if (++bella_comp == 2)
							{
								cout << "Comp has bella.\n";
									sum_comp += 20;
							}
						}
						x1 = your_move_after_comp(Ex);
						cout << "You: " << Ex.get_card_your_move().get_suit() << " " << Ex.get_card_your_move().get_value() << endl;
						if (v_kozir1 == 0 && Ex.get_card_comp_move().get_suit() != kozir_fin&&Ex.get_card_your_move().get_suit() == kozir_fin)
							v_kozir1 = Ex.get_card_comp_move().get_suit();
						else if (v_kozir2 == 0 && Ex.get_card_comp_move().get_suit() != kozir_fin&&Ex.get_card_your_move().get_suit() == kozir_fin)
							v_kozir2 = 0;
						else if (v_kozir3 == 0 && Ex.get_card_comp_move().get_suit() != kozir_fin&&Ex.get_card_your_move().get_suit() == kozir_fin)
							v_kozir3 = Ex.get_card_your_move().get_suit();
						if (Ex.get_card_your_move().get_suit() == kozir_fin && ((Ex.get_card_your_move().get_value() == "Q") ||( Ex.get_card_your_move().get_value() == "K")))
						{
							if (++bella_you == 2)
							{
								cout << "You have bella.\n";
								if (say_bella())
									sum_you += 20;
							}
						}
						if (!x1)
						{
							cout << "Your Book.\n";
							Ex.get_your_books().push_back(pair<Card, Card>(Card(Ex.get_card_your_move().get_suit(), Ex.get_card_your_move().get_value()), Card(Ex.get_card_comp_move().get_suit(), Ex.get_card_comp_move().get_value())));
						}
						else
						{
							cout << "Comp's Book.\n";
							Ex.get_comp_books().push_back(pair<Card, Card>(Card(Ex.get_card_your_move().get_suit(), Ex.get_card_your_move().get_value()), Card(Ex.get_card_comp_move().get_suit(), Ex.get_card_comp_move().get_value())));
						}
					}
					if (j == 9 && !x1)
					{
						sum_you += 10;
						cout << "Vash Last.\n";
					}
					else if (j == 9 && x1)
					{
						sum_comp += 10;
						cout << "Last got the comp.\n";
					}
				}
				erase_suits_move(Ex.get_hearts_comp_dop(), Ex.get_diamonds_comp_dop(), Ex.get_clubs_comp_dop(), Ex.get_speads_comp_dop());
				erase_suits_move(Ex.get_hearts_you_move(), Ex.get_diamonds_you_move(), Ex.get_clubs_you_move(), Ex.get_speads_you_move());
				erase_suits_move(Ex.get_hearts_comp_move(), Ex.get_diamonds_comp_move(), Ex.get_clubs_comp_move(), Ex.get_speads_comp_move());
				
				clear_suits_you(Ex);
				clear_suits_comp(Ex);
				clear_50_20_you_comp(Ex);
				bella_comp = 0;
				bella_you = 0;
				v_kozir1 = 0;
				v_kozir2 = 0;
				v_kozir3 = 0;
				size_hearts_comp = 0;
				size_diamonds_comp = 0;
				size_clubs_comp = 0;
				size_speads_comp = 0;
				words_comp = 0;
				index_suit = 0;
				int you_res = 0;
				you_res = count_books(you_res, Ex.get_your_books());
				int comp_res = 0;
				comp_res = count_books(comp_res, Ex.get_comp_books());
				erase_books(Ex);
				cout << "This hand:\n";
				if (you_res == -1)
				{
					cout << "Vam LbIza.\n";
					cout << "Comp: " << sum_comp + comp_res << endl;
					total_sum_you -= 50;
				}
				else if (comp_res == -1)
				{
					cout << "You: " << sum_you + you_res << endl;
					cout << "Compy LbIza.\n";
					total_sum_comp -= 50;
				}
				else if (you_play && (sum_comp + comp_res > sum_you + you_res))
				{
					cout << "Vam Bajtello.\n";
					total_sum_comp += sum_you + you_res + sum_comp + comp_res;
					++count_bajt_you;
					if (count_bajt_you == 2)
					{
						cout << "Second bajt == -100.\n";
						total_sum_you -= 100;
						count_bajt_you = 0;
					}

				}
				else if (you_play && (sum_comp + comp_res < sum_you + you_res))
				{
					cout << "You: " << sum_you + you_res << endl;
					cout << "Comp: " << sum_comp + comp_res << endl;
					total_sum_you += sum_you + you_res;
					total_sum_comp += sum_comp + comp_res;
				}
				else if (comp_play && (sum_comp + comp_res < sum_you + you_res))
				{
					cout << "Compy Bajtello.\n";
					total_sum_you += sum_comp + comp_res + sum_you + you_res;
					++count_bajt_comp;
					if (count_bajt_comp == 2)
					{
						cout << "Second bajt == -100.\n";
						total_sum_comp -= 100;
						count_bajt_comp = 0;
					}
				}
				else if (comp_play && (sum_comp + comp_res > sum_you + you_res))
				{
					cout << "You: " << sum_you + you_res << endl;
					cout << "Comp: " << sum_comp + comp_res << endl;
					total_sum_you += sum_you + you_res;
					total_sum_comp += sum_comp + comp_res;
				}
				cout << "TOTAL:\n";
				cout << "YOU: " << total_sum_you << endl;
				cout << "Comp: " << total_sum_comp << endl;
				you_play = 0;
				comp_play = 0;
				sum_you = 0;
				sum_comp = 0;
				turn = 0;
			}
		}
		if (total_sum_you > total_sum_comp)
			cout << "You won.\n";
		else
			cout << "Comp won.\n";
		cout << "Want another one?\n";
		cout << "1  Yes  2 No\n";
		string x;
		regex y("1|2");
		while (1)
		{
			getline(cin, x);
			if (regex_match(x, y))
				break;
		}
		if (x == "1")
		{
			total_sum_you = 0;
			total_sum_comp = 0;
			cout << "Let's do it:\n";
		}
		else
		{
			cout << "Have a nice day.\n";
			return;
		}
	}
}