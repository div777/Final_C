#include"Game.h"
Game::Game()
{
 priority_words_you=0;
	 priority_words_comp=0;
	 top_50_you=0;
	 top_50_comp=0;
	 top_20_you=0;
	top_20_comp=0;
}
vector<pair<char, int>>&Game::get_hearts_you_move()
{
	return hearts_you_move;
}
vector<pair<char, int>>&Game::get_diamonds_you_move()
{
	return diamonds_you_move;
}
vector<pair<char, int>>&Game::get_clubs_you_move()
{
	return clubs_you_move;
}
vector<pair<char, int>>&Game::get_speads_you_move()
{
	return speads_you_move;
}
vector<pair<char, int>>&Game::get_hearts_comp_dop()
{
	return hearts_comp_dop;
}
vector<pair<char, int>>&Game::get_clubs_comp_dop()
{
	return clubs_comp_dop;
}
vector<pair<char, int>>&Game::get_diamonds_comp_dop()
{
	return diamonds_comp_dop;
}
vector<pair<char, int>>&Game::get_speads_comp_dop()
{
	return speads_comp_dop;
}
vector<pair<char, int>> &Game::get_hearts_comp_move()
{
	return hearts_comp_move;
}
vector<pair<char, int>> &Game::get_diamonds_comp_move()
{
	return diamonds_comp_move;
}
vector<pair<char, int>> &Game::get_clubs_comp_move()
{
	return clubs_comp_move;
}
vector<pair<char, int>>&Game::get_speads_comp_move()
{
	return speads_comp_move;
}
vector<pair<Card, Card>>&Game::get_your_books()
{
	return your_books;
}
vector<pair<Card, Card>>&Game::get_comp_books()
{
	return comp_books;
}
Card& Game::get_card_your_move()
{
	return your_move;
}
Card& Game::get_card_comp_move()
{
	return comp_move;
}
void Game::set_card_your_move(char a,string& b)
{
	your_move.set_suit_value(a,b);

}
void Game::set_card_comp_move(char a, string&b)
{
	comp_move.set_suit_value(a, b);
}
vector<Card>& Game:: get_you_50_1()
{
	return you_50_1;
}
vector<Card>& Game::get_you_50_2()
{
	return you_50_2;
}
vector<Card>& Game:: get_you_20_1()
{
	return you_20_1;
}
vector<Card>& Game::get_you_20_2()
{
	return you_20_2;
}
vector<Card>& Game::get_you_20_3()
{
	return you_20_3;
}
vector<Card>& Game::get_comp_50_1()
{
	return comp_50_1;
}
vector<Card>& Game::get_comp_50_2()
{
	return comp_50_2;
}
vector<Card>& Game:: get_comp_20_1()
{
	return comp_20_1;
}
vector<Card>& Game::get_comp_20_2()
{
	return comp_20_2;
}
vector<Card>& Game::get_comp_20_3()
{
	return comp_20_3;
}
void Game::set_you_50_1(vector<Card>&Ex, char a, int b)
{
	set_50_helper(Ex, a, b);
}
void Game:: set_you_50_2(vector<Card>&Ex, char a, int b)
{
	set_50_helper(Ex, a, b);
}
void Game::set_you_20_1(vector<Card>&Ex, char a, int b)
{
	set_20_helper(Ex, a, b);
}
void Game::set_you_20_2(vector<Card>&Ex, char a, int b)
{
	set_20_helper(Ex, a, b);
}
void Game::set_you_20_3(vector<Card>&Ex, char a, int b)
{
	set_20_helper(Ex, a, b);
}
void Game::set_comp_50_1(vector<Card>&Ex, char a, int b)
{
	set_50_helper(Ex, a, b);
}
void Game::set_comp_50_2(vector<Card>&Ex, char a, int b)
{
	set_50_helper(Ex, a, b);
}
void Game::set_comp_20_1(vector<Card>&Ex, char a, int b)
{
	set_20_helper(Ex, a, b);
}
void Game::set_comp_20_2(vector<Card>&Ex, char a, int b)
{
	set_20_helper(Ex, a, b);
}
void Game::set_comp_20_3(vector<Card>&Ex, char a, int b)
{
	set_20_helper(Ex, a, b);
}
void Game::set_50_helper(vector<Card>&Ex, char a, int b)
{
	switch (b)
	{
	case 1:
		Ex.assign({ Card(a, "7"), Card(a, "8"), Card(a, "9"), Card(a, "10") });
		break;
	case 2:
		Ex.assign({ Card(a, "8"), Card(a, "9"), Card(a, "10"), Card(a, "J") });
		break;
	case 3:
		Ex.assign({ Card(a, "9"), Card(a, "10"), Card(a, "J"), Card(a, "Q") });
		break;
	case 4:
		Ex.assign({ Card(a, "10"), Card(a, "J"), Card(a, "Q"), Card(a, "K") });
		break;
	case 5:
		Ex.assign({ Card(a, "J"), Card(a, "Q"), Card(a, "K"), Card(a, "A") });
	}
}
void Game::set_20_helper(vector<Card>&Ex, char a, int b)
{
	switch (b)
	{
	case 1:
		Ex.assign({ Card(a, "7"), Card(a, "8"), Card(a, "9") });
		break;
	case 2:
		Ex.assign({ Card(a, "8"), Card(a, "9"), Card(a, "10") });
		break;
	case 3:
		Ex.assign({ Card(a, "9"), Card(a, "10"), Card(a, "J") });
		break;
	case 4:
		Ex.assign({ Card(a, "10"), Card(a, "J"), Card(a, "Q") });
		break;
	case 5:
		Ex.assign({ Card(a, "J"), Card(a, "Q"), Card(a, "K") });
		break;
	case 6:
		Ex.assign({ Card(a, "Q"), Card(a, "K"), Card(a, "A") });
		break;
	}
}
int Game::get_priority_you()
{
	return priority_words_you;
}
int Game::get_priority_comp()
{
	return priority_words_comp;
}
int Game::get_top_50_you()
{
	return top_50_you;
}
int Game::get_top_50_comp()
{
	return top_50_comp;
}
int Game::get_top_20_you()
{
	return top_20_you;
}
int Game::get_top_20_comp()
{
	return top_20_comp;
}
void Game::set_priority_you(int x)
{
	priority_words_you = x;
}
void Game::set_priority_comp(int x)
{
	priority_words_comp = x;
}
void Game::set_top_50_you(int x)
{
	top_50_you = x;
}
void Game::set_top_50_comp(int x)
{
	top_50_comp = x;
}
void Game::set_top_20_you(int x)
{
	top_20_you = x;
}
void Game::set_top_20_comp(int x)
{
	top_20_comp = x;
}
vector<int>&Game::get_hearts_you()
{
	return hearts_you;
}
vector<int>&Game::get_diamonds_you()
{
	return diamonds_you;
}
vector<int>&Game::get_clubs_you()
{
	return clubs_you;
}
vector<int>&Game::get_speads_you()
{
	return speads_you;
}
vector<int>&Game::get_hearts_comp()
{
	return hearts_comp;
}
vector<int>&Game::get_diamonds_comp()
{
	return diamonds_comp;
}
vector<int>&Game::get_clubs_comp()
{
	return clubs_comp;
}
vector<int>&Game::get_speads_comp()
{
	return speads_comp;
}
vector<Card>&Game::get_hand_you()
{
	return hand_you;
}
vector<Card>&Game::get_hand_comp()
{
	return hand_comp;
}
vector<Card>&Game::get_deck()
{
	return deck;
}