#pragma once
#include<iostream>
#include<vector>
#include<iterator>
#include<functional>
#include<fstream>
#include<string>
#include<algorithm>
#include<ctime>
#include<regex>
using namespace std;

class Card
{
	char suit;
	string value;

public:
	Card();
	Card(char, string);
	char get_suit();
	string& get_value();
	void set_suit_value(char, string&);
};